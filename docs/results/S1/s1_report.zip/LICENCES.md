# Licences and attributions of the Sprint 1 test set

Public data, used for evaluation only. Audio and per-utterance texts stay on Drive.

- **edacc**: CC-BY-SA-4.0 (config); dataset card licence field: none stated; revision d9ae7bd344f0562b766ec93ee5ce8f2f9568ce66; edinburghcstr/edacc
- **svarah**: CC-BY-4.0 (config); dataset card licence field: none stated; revision ebbf7777fe771490696a3f7b007097606fa8c924; ai4bharat/Svarah
- **eka_medical**: MIT (config); dataset card licence field: none stated; revision 433e66037c8aebb8f396b938624a5ab6afc4ca36; ekacare/eka-medical-asr-evaluation-dataset
- **earnings22**: CC-BY-SA-4.0 (config); dataset card licence field: none stated; revision 0a034f9ed86d33a3859d9025d3e621cf243773ab; distil-whisper/earnings22
- **harper_valley_bank**: CC-BY-4.0 (config); dataset card licence field: none stated; revision 0bd721e877c4a85d8c13ff837e68661ea6200a98; https://github.com/cricketclub/gridspace-stanford-harper-valley

## librispeech-test-other

LibriSpeech ASR corpus (c) 2014 by Vassil Panayotov, licensed under a Creative Commons Attribution 4.0 International License (https://creativecommons.org/licenses/by/4.0/). Source: https://www.openslr.org/12/. V. Panayotov, G. Chen, D. Povey and S. Khudanpur, "LibriSpeech: an ASR corpus based on public domain audio books", ICASSP 2015. The audio comes from LibriVox public-domain audiobooks.

## musan

MUSAN: A Music, Speech, and Noise Corpus, by David Snyder, Guoguo Chen and Daniel Povey (arXiv:1510.08484), released as a corpus under a Creative Commons Attribution 4.0 International License (https://creativecommons.org/licenses/by/4.0/). Source: https://www.openslr.org/17/. Each file's own licence is the one the LICENSE file of its MUSAN folder gives.
