# Decision inputs (WP-1.3)

Figures for docs/results/S3/DECISION.md. The decision and the architecture blueprint are the owner's.

## Gate thresholds within the escalation limit

```json
{
  "channel": {
    "cohere-transcribe-2b": {
      "feature": "channel",
      "rate": 0.35,
      "sign": 1,
      "threshold": Infinity
    },
    "qwen3-asr-1.7b": {
      "feature": "channel",
      "rate": 0.35,
      "sign": 1,
      "threshold": Infinity
    }
  },
  "confidence": {
    "cohere-transcribe-2b": {
      "feature": "confidence",
      "rate": 0.35,
      "sign": -1,
      "threshold": -0.9660061270418302
    },
    "qwen3-asr-1.7b": {
      "feature": "confidence",
      "rate": 0.35,
      "sign": -1,
      "threshold": -0.9660061270418302
    }
  },
  "digits": {
    "cohere-transcribe-2b": {
      "feature": "digit_tokens",
      "rate": 0.35,
      "sign": 1,
      "threshold": 1.0
    },
    "qwen3-asr-1.7b": {
      "feature": "digit_tokens",
      "rate": 0.35,
      "sign": 1,
      "threshold": 1.0
    }
  },
  "duration": {
    "cohere-transcribe-2b": {
      "feature": "duration_s",
      "rate": 0.35,
      "sign": 1,
      "threshold": 9.4000625
    },
    "qwen3-asr-1.7b": {
      "feature": "duration_s",
      "rate": 0.35,
      "sign": 1,
      "threshold": 9.4000625
    }
  },
  "entropy": {
    "cohere-transcribe-2b": {
      "feature": "entropy",
      "rate": 0.35,
      "sign": -1,
      "threshold": -0.17969459271642307
    },
    "qwen3-asr-1.7b": {
      "feature": "entropy",
      "rate": 0.35,
      "sign": -1,
      "threshold": -0.17969459271642307
    }
  },
  "hybrid": {
    "cohere-transcribe-2b": {
      "feature": "hybrid",
      "rate": 0.35,
      "sign": 1,
      "threshold": 0.2868610751219863
    },
    "qwen3-asr-1.7b": {
      "feature": "hybrid",
      "rate": 0.35,
      "sign": 1,
      "threshold": 0.3494037618186906
    }
  },
  "nonspeech": {
    "cohere-transcribe-2b": {
      "feature": "nonspeech_ratio",
      "rate": 0.35,
      "sign": 1,
      "threshold": 0.20669291338582674
    },
    "qwen3-asr-1.7b": {
      "feature": "nonspeech_ratio",
      "rate": 0.35,
      "sign": 1,
      "threshold": 0.20669291338582674
    }
  },
  "words_per_s": {
    "cohere-transcribe-2b": {
      "feature": "words_per_s",
      "rate": 0.35,
      "sign": -1,
      "threshold": -2.1466785181209853
    },
    "qwen3-asr-1.7b": {
      "feature": "words_per_s",
      "rate": 0.35,
      "sign": -1,
      "threshold": -2.1466785181209853
    }
  }
}
```

## Gates

- cascade gate: FAIL
- drug recall: FAIL
- us_conv non-regression: FAIL

