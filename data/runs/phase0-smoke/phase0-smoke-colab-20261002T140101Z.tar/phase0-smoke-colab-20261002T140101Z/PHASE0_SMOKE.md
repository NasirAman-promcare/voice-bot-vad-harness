# Phase 0 smoke run: target colab

Bundle `phase0-smoke-colab-20261002T140101Z` (bundle format 1.0, docs/runs/PHASE0_SMOKE.md), written 2026-10-02T14:01:01Z on colab:718ce26c003c.

- Machine: platform colab, Intel(R) Xeon(R) CPU @ 2.00GHz, x86_64, Ubuntu 24.04.4 LTS, Python 3.13.15, GPU Tesla T4.
- Code: git commit `7c27dd53e670d1a207be8738873eeb22bc1ce968` (dirty: false).
- Locks: `requirements/aqis_lab/phase0.txt` sha256 `87a1cc34c6d41388cf8ce1e415f95f61c3b24a7bc45b69a828a957c1813fdcef`, `requirements/aqis_lab/phase0-gpu.txt` sha256 `837342085aedf769ce4bf8de055ec0168ddc9ee3667b7ab14865592d8157b451`.
- Elapsed: 374.4547 s (NFR-0.7-01: at most 900 s on the cloud VM).

Every number below is printed from a file of this bundle. A table row names its result row: add the bundle's run and score folders to a results store (`python -m aqis_lab results add --run runs/<task>`, then `--scores scores/<table>`) and run `python -m aqis_lab trace <row>`.

## Runs

| task | run card | mode | clips | results.jsonl sha256 | events |
| --- | --- | --- | --- | --- | --- |
| vosk-batch | `daadff54bb7238a62ff71f779aa5e5316a7df1e7bf936d6cf262ed3912d83384` | batch | 60 | `3c08419f3867a4feaffdae3c5ee128682b900352593ce95dd2e6e8cc5d1d6eb9` | 894 |
| harness-vad | `482ec4f183dfdefb69e64591f938d834a54e477a9089c35d570168c5dbce0b7c` | batch | 60 | `518b9f1533ebb8ae656a5f9153c1d3f93c0203dcd9fb8bd1b76658cf692bda14` | 462 |
| vosk-realspeed | `21574e5ca8e07c54312fd184a5e15bfd3837ecef401eb1bf4196de870e659ca8` | realspeed_cpu | 5 | `8fa40e89250383e28fb96d71a99909671c16e7a1535fb88b45fe7d2e797a5e51` | 81 |
| parakeet-offline | `7b4eef66a74701d8a259b10bb9aa425052fcf626aee3cafce2eb5c3f0dcd1c63` | batch | 60 | `4053203fe03511ac01f26a0d0b418e860f9a2f5cd0ddd51b58112096a1705503` | 182 |
| parakeet-compute-delay | `223b42abba178bf7d519e941ed066d5bc19c320e5f58c4b20c0c4345ce98c80d` | gpu_compute_delay | 5 | `4e06d2aaca80f23233a185e5720e3d6db8432f6237ab616246373d557b6b2b06` | 17 |

## Word error rate (WP-0.3 scorer)

Tables `*-synthetic-tts` are synthetic TTS speech: plumbing only, never a model judgement (docs/data/SMOKE_PACK.md).

| table | variant | corpus WER | errors | reference words | corpus CER | summary.json sha256 |
| --- | --- | --- | --- | --- | --- | --- |
| vosk-batch-natural | disfluency_aware | 0.1074 | 74 | 689 | 0.0528 | `974cdf1fef8befdb0d3f4503d92657e54456ffb63b31059b99fe341d313cb1d5` |
| vosk-batch-natural | main | 0.1074 | 74 | 689 | 0.0528 | `974cdf1fef8befdb0d3f4503d92657e54456ffb63b31059b99fe341d313cb1d5` |
| vosk-batch-synthetic-tts | disfluency_aware | 0.0476 | 3 | 63 | 0.0115 | `55698cf450b1215ceac133f62a087ca95e4bd34561af6fa67f3837f947cf917b` |
| vosk-batch-synthetic-tts | main | 0.0476 | 3 | 63 | 0.0115 | `55698cf450b1215ceac133f62a087ca95e4bd34561af6fa67f3837f947cf917b` |
| parakeet-offline-natural | disfluency_aware | 0.0058 | 4 | 689 | 0.0024 | `6c92791b4bc7c11a9b62c01b90147e15423de418924722a9fd32e51058413156` |
| parakeet-offline-natural | main | 0.0058 | 4 | 689 | 0.0024 | `6c92791b4bc7c11a9b62c01b90147e15423de418924722a9fd32e51058413156` |
| parakeet-offline-synthetic-tts | disfluency_aware | 0.0317 | 2 | 63 | 0.0029 | `611f70f5a93463d03cefa665518f152ed1043f850b7c263cc629f0bd4799f7ea` |
| parakeet-offline-synthetic-tts | main | 0.0317 | 2 | 63 | 0.0029 | `611f70f5a93463d03cefa665518f152ed1043f850b7c263cc629f0bd4799f7ea` |

### WER per clip (variant main)

| table | clip_id | wer | errors | ref_words | row |
| --- | --- | --- | --- | --- | --- |
| vosk-batch-natural | ls-test-clean-1188-133604-0029 | 0.1111 | 1 | 9 | `264c59387cfca00536b0d77f4ae82d406e59757df282e527469b44f705b4028f` |
| vosk-batch-natural | ls-test-clean-121-127105-0012 | 0.1429 | 3 | 21 | `2b3047208600b878bed892079b4cfaa36d0df3fc07e837b13dc4a0de677cf3bd` |
| vosk-batch-natural | ls-test-clean-1221-135767-0014 | 0.0500 | 1 | 20 | `05c05ee6c96aac7d4e4d46c66fa6d0d6ec5c044a02a03430477bbedb6f94fea7` |
| vosk-batch-natural | ls-test-clean-1580-141083-0035 | 0.0769 | 1 | 13 | `ed6e665326f90308a6e7731d869f3fc2f4098d9453e8b4c97a4c93976aa5eb76` |
| vosk-batch-natural | ls-test-clean-237-134493-0011 | 0.0000 | 0 | 19 | `566db855ad13fefab38af0829e67c7dc67f0bb9ca0315a9ef105910a75c3fe39` |
| vosk-batch-natural | ls-test-clean-2830-3980-0007 | 0.0909 | 3 | 33 | `cf789692f8943f3b2e57468895a8c0b63aff5e6dbe2bf911d67f84460983dab1` |
| vosk-batch-natural | ls-test-clean-3570-5695-0009 | 0.0714 | 1 | 14 | `801fa5b591d7f46e51c70185a197f72458ea8beafbddc4fc2eb9b5dd26b279eb` |
| vosk-batch-natural | ls-test-clean-4077-13751-0014 | 0.1471 | 5 | 34 | `8239542b20497e284d933768edbd913e5199df4d80d6f6f3f0dfda747d5f4305` |
| vosk-batch-natural | ls-test-clean-4446-2271-0024 | 0.0769 | 1 | 13 | `8faa987ecaf52314d7283db7d09ddb1324a1b438c9daa81ef0470602787818c9` |
| vosk-batch-natural | ls-test-clean-4507-16021-0058 | 0.0000 | 0 | 8 | `756281d5dd4ff3743980bc4862f7749ddf50ba4aa5540b2fdac28cc052c05808` |
| vosk-batch-natural | ls-test-clean-4970-29095-0002 | 0.0769 | 1 | 13 | `5c2c053dd2fd36b6c0e412c7a7db4c9151dbd3d485aac67de54db16284514b88` |
| vosk-batch-natural | ls-test-clean-4992-41797-0015 | 0.0333 | 1 | 30 | `e97c1c3c44646f1b83687166532f8a6014acfa96b1877836ec6dff8b0a1b86d0` |
| vosk-batch-natural | ls-test-clean-61-70970-0011 | 0.1333 | 2 | 15 | `60728020d172e7e33e4db8c16e17f707c8579a34a40ee634726bccbe51cfcd0a` |
| vosk-batch-natural | ls-test-clean-6829-68771-0030 | 0.0000 | 0 | 17 | `2d974fd2f585d12b07f72ca988559f27efaf9887c386681cd1865d96d09f95f4` |
| vosk-batch-natural | ls-test-clean-7127-75946-0009 | 0.0000 | 0 | 12 | `4926246fc3650e94550d46ffa17ba1428b71b14b58480f54489544063d6824e4` |
| vosk-batch-natural | ls-test-clean-7176-92135-0018 | 0.0370 | 1 | 27 | `3c3b9469589045dd248d9acb0dacd9b12cb8b19650dba05c264bbfe08c24b427` |
| vosk-batch-natural | ls-test-clean-7729-102255-0023 | 0.0000 | 0 | 10 | `6ae842679144b912f4ea82a5988ec622016b9a69f1048f56c70e810aec146cac` |
| vosk-batch-natural | ls-test-clean-8230-279154-0011 | 0.0000 | 0 | 12 | `7bdd777af7c20b5a5ad81cebf788843059487986cc175e0a69a1c8026db5d021` |
| vosk-batch-natural | ls-test-clean-8455-210777-0037 | 0.0000 | 0 | 10 | `b453e612227666044bf8526b5de59b9ee3764306be02107b2f5d3e42ef397b87` |
| vosk-batch-natural | ls-test-clean-908-157963-0014 | 0.2727 | 3 | 11 | `28e9fab4d9a8ac7c698795564d91a5daf0249f57b3886565791b3b9814bbac77` |
| vosk-batch-natural | ls-test-other-2609-156975-0000 | 0.5455 | 6 | 11 | `6cfafe4d4ab95fc213fbfaa04e13d80495eabe35833b8a69aba8598d1fed6f48` |
| vosk-batch-natural | ls-test-other-3080-5040-0016 | 0.0526 | 1 | 19 | `b2a35d1003febb14b3233a166a3d5596b7a264cf96d481d31813a1ba4d7ae28c` |
| vosk-batch-natural | ls-test-other-3528-168669-0043 | 0.3000 | 3 | 10 | `01947f9c30a9ae7734859e184897c46104e15db8231e6ffc4503ea9f0e67a058` |
| vosk-batch-natural | ls-test-other-3538-142836-0006 | 0.0000 | 0 | 18 | `ad3079bfce157d505b40aa0837095e45d8f98cd83bbc8ae9f17a10bff1ba76a6` |
| vosk-batch-natural | ls-test-other-4198-12259-0026 | 0.4615 | 6 | 13 | `0c4c7e35215b59b43283d204a63fc493e614b79c5273e7f94dcde9634e4ea11c` |
| vosk-batch-natural | ls-test-other-6128-63244-0013 | 0.6364 | 7 | 11 | `4a7b481ee7f1066197a8cb71d07fc34f46ced0705406a6753854cafca3ab720d` |
| vosk-batch-natural | ls-test-other-6432-63723-0046 | 0.0000 | 0 | 19 | `500ac5f0e08fa7441f27b2a6b2c4ee1583bf93261bb6fd85a6945ee87cc6a7b5` |
| vosk-batch-natural | ls-test-other-7105-2340-0033 | 0.0000 | 0 | 27 | `6a50d1b8a8875ffdb1378f9124cc64abc19b30778860cd8782c76c9e090d90af` |
| vosk-batch-natural | ls-test-other-8188-269288-0027 | 0.1667 | 2 | 12 | `568bee79e23f20f4dbe52335fbfb6e7276092e54923e40d377dbdfd9b78cc95f` |
| vosk-batch-natural | ls-test-other-8280-266249-0004 | 0.1176 | 2 | 17 | `3fd2d40960591c15fdceebeec86ecd53b0f8e4d7b7d68c72d3733fc359b91f4e` |
| vosk-batch-natural | smoke-mix-01 | 0.2500 | 3 | 12 | `ec65f6b39f5d165afe8d3721ad35621bfc322b7b8a8832c0efcdd9d8e5fa583f` |
| vosk-batch-natural | smoke-mix-02 | 0.3333 | 8 | 24 | `ee6fab5cbf165475b95bad1537d199b938618a0de32c0a7b71ab48174a103c32` |
| vosk-batch-natural | smoke-mix-03 | 0.0000 | 0 | 19 | `5213089d9322b8ad2b8d89c57a9a25262f36d062cc5ee3560695d958695c3458` |
| vosk-batch-natural | smoke-mix-04 | 0.0000 | 0 | 14 | `274bca257273c509ce6440e7435c67423232085a6813c4001f2057172f8e1077` |
| vosk-batch-natural | smoke-mix-05 | 0.0625 | 1 | 16 | `f268e52de3b397db6b6cd3059b9c7452509182bf70702b6f884cfd9e216ddcbf` |
| vosk-batch-natural | smoke-mix-06 | 0.2000 | 2 | 10 | `54a505867aa82bdef840331caea701bbe335e83e8ebf68fd2bcdbc74cb741284` |
| vosk-batch-natural | smoke-mix-07 | 0.0385 | 1 | 26 | `ae03b4d88f29d294ba47b851eadb181cad428b763234c5ae609c3552eb86241c` |
| vosk-batch-natural | smoke-mix-08 | 0.0870 | 2 | 23 | `a173d18c9e5de248f352d9b82a1a71c72808a36614ca568b82c2fbf3d4065e59` |
| vosk-batch-natural | smoke-mix-09 | 0.1481 | 4 | 27 | `46619bef3800f4fc5ab2c13cdbeab64bc2ef37de59ed0e3176048f8a62b8af6f` |
| vosk-batch-natural | smoke-mix-10 | 0.1000 | 2 | 20 | `32b500b140207bd0b5f3e99187f17a7156e3e00bbd963571f4eb12c0557321fd` |
| vosk-batch-synthetic-tts | tts-smoke-01 | 0.0000 | 0 | 1 | `9736b8aba0457e32fc8815403420dd3431c71ec8915117b4be1d52a263fb6039` |
| vosk-batch-synthetic-tts | tts-smoke-02 | 0.0000 | 0 | 10 | `ffc9110296938acfbed07d71349f02eea61eda153e508fd78d2c968c640ddfa6` |
| vosk-batch-synthetic-tts | tts-smoke-03 | 0.0000 | 0 | 1 | `0f228f8a965ddd1d96a78f5ade243ea545715b689fc54b41ff19fdd2a8ab7e2c` |
| vosk-batch-synthetic-tts | tts-smoke-04 | 0.1111 | 1 | 9 | `d5e3382f04ada15737d4e79300c3962d7154ac2fceb71d752ffd6c2dd4c1990c` |
| vosk-batch-synthetic-tts | tts-smoke-05 | 0.0000 | 0 | 1 | `bd5c1c8b349833ca4d4208e45d9a015808a5854c56e18805980c2fbf28769aec` |
| vosk-batch-synthetic-tts | tts-smoke-06 | 0.0000 | 0 | 14 | `149b42fd9aeb24e0c08a078a50247b0320f95b42a68e34622b40f6616c7092a9` |
| vosk-batch-synthetic-tts | tts-smoke-07 | 0.0000 | 0 | 1 | `74779d4bbe1aafb6ad18c2927e9cb045661454816c329f17741c61a319b09de9` |
| vosk-batch-synthetic-tts | tts-smoke-08 | 0.0000 | 0 | 12 | `8e4b1a8074d5c020f7140836ca1abf7126013588699eef65a7756fe3c5b6b2f2` |
| vosk-batch-synthetic-tts | tts-smoke-09 | 0.0000 | 0 | 1 | `df7da675123b0720c5caba6d361b4355ebd742d99cba9ebd188a27e2bac75f31` |
| vosk-batch-synthetic-tts | tts-smoke-10 | 0.1538 | 2 | 13 | `42c27600d5e3048559762354c8fe30625d639fed5dee299af96ee47af8a47b3a` |
| parakeet-offline-natural | ls-test-clean-1188-133604-0029 | 0.0000 | 0 | 9 | `98371a72dc947c1ba27bf1be243cbcc653cee26d030bd72507b863efd06f55a3` |
| parakeet-offline-natural | ls-test-clean-121-127105-0012 | 0.0000 | 0 | 21 | `e90808312d69c8b10271b6f2568fb7275549776b850fa365f7d9c432b1970f61` |
| parakeet-offline-natural | ls-test-clean-1221-135767-0014 | 0.0000 | 0 | 20 | `4f9c8bb65d428c8bd663876d1b9fe47cfce745ec9a615a65ad2fd29008ae180f` |
| parakeet-offline-natural | ls-test-clean-1580-141083-0035 | 0.0769 | 1 | 13 | `13e29c60c60122f34cd14ec639c6577baa4aae109cae8a6d1a7e8a89de473b71` |
| parakeet-offline-natural | ls-test-clean-237-134493-0011 | 0.0000 | 0 | 19 | `030526a09279e773cd7fbbd11bcad4b75cd7c495283089eed29f2b23acbcaa95` |
| parakeet-offline-natural | ls-test-clean-2830-3980-0007 | 0.0000 | 0 | 33 | `1646c937fd3fbff82bd7b660d64fda409e7dc5430e797555da0b5c369a9e2530` |
| parakeet-offline-natural | ls-test-clean-3570-5695-0009 | 0.0000 | 0 | 14 | `387976f921660b7298bcf45abc7e4190f561218cb47c14b7c9ce4648d72bb1b5` |
| parakeet-offline-natural | ls-test-clean-4077-13751-0014 | 0.0000 | 0 | 34 | `dc8f43d3ec8ecd80c237d7fc3c47c5610372d5be7c063b74bfaaf10897efb1a5` |
| parakeet-offline-natural | ls-test-clean-4446-2271-0024 | 0.0000 | 0 | 13 | `66e08226a760d17374601ce875c854ddb397dd5343dc76df7ac9b61469ea609f` |
| parakeet-offline-natural | ls-test-clean-4507-16021-0058 | 0.0000 | 0 | 8 | `3c17e622bbfc4bdf96184419191c6f126a127bbb36320d929abe24c738098f0e` |
| parakeet-offline-natural | ls-test-clean-4970-29095-0002 | 0.0000 | 0 | 13 | `57a284fe0b88c26b77193aa277036ca17a0c502592158fb48ed86c288006e86c` |
| parakeet-offline-natural | ls-test-clean-4992-41797-0015 | 0.0000 | 0 | 30 | `3dc568cf1d3d6109ba5d59617b6d76f1c1226d09989d67b852478c1a875bbd8f` |
| parakeet-offline-natural | ls-test-clean-61-70970-0011 | 0.0000 | 0 | 15 | `479432a16e5f73cca3eb68660899c0f416ddfb486ff12f19589d1a35c030f817` |
| parakeet-offline-natural | ls-test-clean-6829-68771-0030 | 0.0000 | 0 | 17 | `a08331c9dd6f1256c3ac90be57fbddc253b3d2595351144791a9cf1963ebd507` |
| parakeet-offline-natural | ls-test-clean-7127-75946-0009 | 0.0000 | 0 | 12 | `781287ace81d20b1a82095edc834bf738e03e5f1f8990ba91d35c2e8ee9a87b9` |
| parakeet-offline-natural | ls-test-clean-7176-92135-0018 | 0.0000 | 0 | 27 | `6bd01f2652b58c2c7792615402c933eb4462af5fb651678b70ecba080d12bc6f` |
| parakeet-offline-natural | ls-test-clean-7729-102255-0023 | 0.0000 | 0 | 10 | `a6fc24c922bcefde56d18bd51506826d6f25160d6c7ce0501c140351b2a41020` |
| parakeet-offline-natural | ls-test-clean-8230-279154-0011 | 0.0000 | 0 | 12 | `1f3e853b3074551011255a66ee187cb8680ec266e46f7502a720dce6b5b904e0` |
| parakeet-offline-natural | ls-test-clean-8455-210777-0037 | 0.0000 | 0 | 10 | `ed9e98088ad394c25ab418af0fef897348be50a957c0be33e3b30b0dbddc9694` |
| parakeet-offline-natural | ls-test-clean-908-157963-0014 | 0.0000 | 0 | 11 | `b4b3dcd0070f121a39ac33f811ea223f42312eb411e250e32994c1b3d21fa33b` |
| parakeet-offline-natural | ls-test-other-2609-156975-0000 | 0.0000 | 0 | 11 | `b69059efa629d898ab4f343916cec13e1a1961516d4d6d4ec5bcf171fb54d61d` |
| parakeet-offline-natural | ls-test-other-3080-5040-0016 | 0.0000 | 0 | 19 | `7b0746837479061420090b3deb62717a78a075c444a1c9e196bf4b4b2873b38a` |
| parakeet-offline-natural | ls-test-other-3528-168669-0043 | 0.0000 | 0 | 10 | `14242d79d684adb4ffbb7c352fd72a630ea4b3658849d9a4e93931e8e8a8a273` |
| parakeet-offline-natural | ls-test-other-3538-142836-0006 | 0.0000 | 0 | 18 | `bb86c2f8395ed15101a22081cce49a4833702221b3a54f47b9a7e66e351168e8` |
| parakeet-offline-natural | ls-test-other-4198-12259-0026 | 0.0000 | 0 | 13 | `e58b84273622d481c85b9805d2e8f85d0566e34fa44f8146519d8f6fe23486fa` |
| parakeet-offline-natural | ls-test-other-6128-63244-0013 | 0.0000 | 0 | 11 | `5d311990e195ea226986b1fd9ca4d743f9ad401de5b32e0d8fce01e96ebc5cca` |
| parakeet-offline-natural | ls-test-other-6432-63723-0046 | 0.0000 | 0 | 19 | `669bebf991586f18b91099313cedae1782c6760b6f9b745f31e504714e68a48f` |
| parakeet-offline-natural | ls-test-other-7105-2340-0033 | 0.0000 | 0 | 27 | `fe6b42bcf4f0813fa48fc13e09fc198e8a4d74e22d87746d57698d4b939d19c4` |
| parakeet-offline-natural | ls-test-other-8188-269288-0027 | 0.0000 | 0 | 12 | `9029bc6bc0ff059e30d32bcc5669cfb5fb081fce2851a16d6cfeb84ddfeeda73` |
| parakeet-offline-natural | ls-test-other-8280-266249-0004 | 0.0588 | 1 | 17 | `47ecc363b8bf131616b633ecb28518fd196d59bdea4dca2fe42098d7b3870647` |
| parakeet-offline-natural | smoke-mix-01 | 0.0833 | 1 | 12 | `2a52a2a57680597233086fb88ab3f78dba0e7bb19a2c595a9f90a93a915a273f` |
| parakeet-offline-natural | smoke-mix-02 | 0.0417 | 1 | 24 | `44fe377d580d3afa43b1280f2d4e03a01d5854f0727b2af8fdb6438ec048cd0a` |
| parakeet-offline-natural | smoke-mix-03 | 0.0000 | 0 | 19 | `37fe5f0c7441ea556524f9182ab61ea39ac8835629156f3a2a836984c8cfa9b8` |
| parakeet-offline-natural | smoke-mix-04 | 0.0000 | 0 | 14 | `b392bc2257da8bfc639f930d5ddcf93db00eb8f7b6aa5d33b44ca9f82552af8b` |
| parakeet-offline-natural | smoke-mix-05 | 0.0000 | 0 | 16 | `2ce785120497c5367168377bc278d7c6f690b5460d38ad21b4acbd6785d00cb4` |
| parakeet-offline-natural | smoke-mix-06 | 0.0000 | 0 | 10 | `e14ae2f39799cfb01e54f3495a4d43e9ec8bcdcd8486a90f4d63a1433c472e1d` |
| parakeet-offline-natural | smoke-mix-07 | 0.0000 | 0 | 26 | `f5c9160664ea14aac710bd9647fa5fed6cbfdefdbb32784ad52d6feb33a5d24d` |
| parakeet-offline-natural | smoke-mix-08 | 0.0000 | 0 | 23 | `c324071579623d099f4af522d3663951c12e29e162b97f443b0fbe83c160fbb1` |
| parakeet-offline-natural | smoke-mix-09 | 0.0000 | 0 | 27 | `a2391fdfa10be1e5992cc60650da645df3702468b819ea342a5cf8326747d65d` |
| parakeet-offline-natural | smoke-mix-10 | 0.0000 | 0 | 20 | `0b8d4f6bdc55dcbb8ca3b2694d902ff5ba66bd36c235be41c3b4d7e517b68b20` |
| parakeet-offline-synthetic-tts | tts-smoke-01 | 0.0000 | 0 | 1 | `c6f4769f8add0e65ada88833d400ed93fccd8f1b25264a435a3fbffa5732ae59` |
| parakeet-offline-synthetic-tts | tts-smoke-02 | 0.0000 | 0 | 10 | `e674dd8129cb2548cfa0654b4b06c608b945340d005cf4752f7322daf69d394c` |
| parakeet-offline-synthetic-tts | tts-smoke-03 | 0.0000 | 0 | 1 | `3d1b25ae5d3d61d1836c82c3f076c04a969c85ab8c7880c46301450d5a7f8014` |
| parakeet-offline-synthetic-tts | tts-smoke-04 | 0.0000 | 0 | 9 | `588ca8cbb91a85db0b874201e068acf205cf85e1a46670361a8c160f2f0dc9aa` |
| parakeet-offline-synthetic-tts | tts-smoke-05 | 0.0000 | 0 | 1 | `8d05d49559bf5497f5f3cbd449600cfd76e7bdea84ed4dfea662ab9f60f54001` |
| parakeet-offline-synthetic-tts | tts-smoke-06 | 0.0000 | 0 | 14 | `a2aedaeb7f0e58353debd1f21fc1a2ac46714014841aba55dd1706c03acdb09e` |
| parakeet-offline-synthetic-tts | tts-smoke-07 | 0.0000 | 0 | 1 | `78dc0f1f41eda63be98817616ac4bfe77923109388f01b1b8561f2bc5412b175` |
| parakeet-offline-synthetic-tts | tts-smoke-08 | 0.0000 | 0 | 12 | `6e167eeb456c9803ca21d7ba27eff20e90c4fc3eb3adf7706dda2751ca99e0a8` |
| parakeet-offline-synthetic-tts | tts-smoke-09 | 2.0000 | 2 | 1 | `a37c011ca0cf217f0944fd2362267e0a3d706eb87cd3df17e581d4131ddc6779` |
| parakeet-offline-synthetic-tts | tts-smoke-10 | 0.0000 | 0 | 13 | `72c527c61342fb13243b5363cb77e4668518cc66e08ed26c0411f1690cc51193` |

## Vosk batch transcripts (60 clips)

| category | clip_id | words | text_sha256 | row |
| --- | --- | --- | --- | --- |
| test-clean | ls-test-clean-1188-133604-0029 | 9 | ed0cdc46462af3fd85466e4075531ee6d435532e1ec02e0590bba2cf4537a288 | `61000cc70e72a1d2ed3ec200e40e117e0cd86e20a4d3df1db560c9e84af06e07` |
| test-clean | ls-test-clean-121-127105-0012 | 18 | 699ad819bfcf8b39789087c3f0b15bf114c1c75b75f6e8ef6f0133c9ca259a29 | `9b25600b1c67df8d3911596d735fca808dd6baba17bdcedbc000f2ed67e1d39a` |
| test-clean | ls-test-clean-1221-135767-0014 | 20 | 77eeb5c74e6a837f48d06d5d1c6e82e20d660dfb2f67893eb1545cfb971a1f5b | `a435fb4dad67b63af26f167df55fa8384638f835b36240fc289f2716c29f8c47` |
| test-clean | ls-test-clean-1580-141083-0035 | 13 | 7ed7925898bfabeb4443421409c639975eb0d4b8e1e5791df7871786d038e48e | `6676491f25958e92e47f5b3de212e74604fcf820ac0324d06b34ab86e07a2f82` |
| test-clean | ls-test-clean-237-134493-0011 | 18 | cd082978af6d92788438beec92e61403187c2a8d86ce1802c07fb22976191948 | `1ceb2e86950f92c274130f988091257909e96eb7732b22d1429affd9a545fe6d` |
| test-clean | ls-test-clean-2830-3980-0007 | 33 | 36af36ac244f4016d204bd3b991eb497bf48a15378c9434b726cb95846437cce | `108cf2d2e3cf9328c2e68ef2a06544f16e8bf4ed70788b2773b43f91c276b150` |
| test-clean | ls-test-clean-3570-5695-0009 | 15 | cff865c42fc22044f4f00219966c7fa5ff6d5718c9ff254e632e78630becf5a0 | `05ebb45812c2281f2783a44eebebe48e991133e4dbf5693783a0825071a3b8be` |
| test-clean | ls-test-clean-4077-13751-0014 | 36 | 79d2318af8535b69de087760526f0ec46274301bf72765f91266629cb4b3be9c | `40cc29a7679b4025e3ef0689017b49131a9f27bcc6ce8871426f657d00d287e6` |
| test-clean | ls-test-clean-4446-2271-0024 | 11 | 74d466a6d2a3cd1a476bb21b1227a108c9f342eeed7caf78905599b9d01fa9aa | `708f9ab4bf1c904c3ed4d3049fbc01942df1f0ae985b25e008b077c9cbfbab34` |
| test-clean | ls-test-clean-4507-16021-0058 | 8 | c236cd7f13c7f2639ac253c309b6c21d546aac29f50593b3ba1e7f84fe616c8c | `5438153e612602e60b7124640715d1ffa3b6eafc585236214100ea4cb9451250` |
| test-clean | ls-test-clean-4970-29095-0002 | 13 | 65fe9e8d47aff0d42b5918fa9aafe611fdddc93b8858e466b9577efe91a7ad12 | `1bc7670232be46e3d6a7e443cadad645595c41695aeabca735c78d11267e49e3` |
| test-clean | ls-test-clean-4992-41797-0015 | 30 | 1fc5773314919c8012f97d56723388a6befb7c5cc17f463fa830398330a0a4fe | `7c0a0230d9b356449afd966a12e13998c18876458b0beed72a0ec202a9bf29f8` |
| test-clean | ls-test-clean-61-70970-0011 | 16 | 75e669b68ccb7686f78d6227dbbfc25e9f66e3dc6b817b02a2fab5c1196d94b7 | `ceb5716f1f9e8b501449c847dbf9298fa94170e8d0285849116e377bddf16b25` |
| test-clean | ls-test-clean-6829-68771-0030 | 17 | fbb99918869de67cd11ecd35fccf05d3b9ba7ba0de5d1183db2ceaa10a3ef5f0 | `db6fe8ff95d0b15d77e36edd24ee3fe2fa87bd8e6009b079cdc5f26d04d88bea` |
| test-clean | ls-test-clean-7127-75946-0009 | 12 | b65a6039e3d0f4bdde3eb8f7c193af2bf48ff82369965e3310e3ccab78bc0d08 | `6a83e2689e4d5282bee3e637dbe56b341103269835489b9975ba76565cb9193e` |
| test-clean | ls-test-clean-7176-92135-0018 | 27 | f49073c8aa17da02b2b0639369978d3a4c4af8dd74a1cff0f4614953a2ac666e | `2b1c56c11ca96827cdd946bd6d6bd571500a7d1fa3b8561ded1808a4bd4f6125` |
| test-clean | ls-test-clean-7729-102255-0023 | 10 | 996a32b70e1851af5372a32bbc2b2899bf06bbbd161a9414a1f99118f26a8a24 | `5954c6d74ec9a3cd8cdbee85674e54815ec40b39d328bee0fb564d177f863533` |
| test-clean | ls-test-clean-8230-279154-0011 | 12 | dc8cb596dd4211fd11b0e55f11f8192c425d43957fbc795f33d5f8be372b78ff | `f2ce10d86ab3831eab331a384a3d2c317d1c8284b6c6529d8430c303345f8df9` |
| test-clean | ls-test-clean-8455-210777-0037 | 10 | 4af3329969e0f398ea43d2be7b278776baa1bed28e313c0e2f091da363256aa1 | `503bd157772d9b25b264cba6c1653281d3207a9b42f30ad7c112f5a888eb8326` |
| test-clean | ls-test-clean-908-157963-0014 | 11 | 35bb92d7da9f5472ab74a0fd16688e9739d86999017882ca2c8358a3a5dfb405 | `083e406d6d1f420d1a6c5691bd2a16cd8ce9d8e08407aefb360a114c6c3c8caa` |
| test-other | ls-test-other-2609-156975-0000 | 12 | da4a25a42447ac2efb2c4bf427ee83cabbf789e51a20cfbe95fda8461c26d76b | `f75a5aec1b09f9926461bf34d93c5740205ff54ca50876895aeee76f9c975677` |
| test-other | ls-test-other-3080-5040-0016 | 18 | d95e960697381f2d028985cd69b7569eb5cfeaaf3adb33e47449f3f0dfe694ad | `651088041c3c01362372fcb0d8c4beafeb62b21ccc96afc08e3d264e32a0df1d` |
| test-other | ls-test-other-3528-168669-0043 | 10 | d071a0bdb47a8d924c03c62240613d04335ed61caec31ccde0facef042f92f84 | `7ee2131306b78476da0b5cb65a2075a91df22c0a9209c9c811c9d4139e42bee9` |
| test-other | ls-test-other-3538-142836-0006 | 18 | a3e636a5813ed01e48756a32859c4a32cc5edb17c700a1410d0eaecdd65a4284 | `29a1ac468744eb185058bf6f3ef135e54c8ae3a785912294c07ede342c4d46bd` |
| test-other | ls-test-other-4198-12259-0026 | 15 | 776f18edf77e50dd07f3de821c05c8bd71a0696fa27e36433e3c0ac5b227dc50 | `4a2bba97d6f6a78e3fda53de161eaec4c6ffe4909a1b8fb01e3ba07ddcaacf6a` |
| test-other | ls-test-other-6128-63244-0013 | 10 | cdc1c8aa9174b98c2eaf0cfe2ddb73d6b2361c347227b38a2ffc0d5ead5c4383 | `6b86b6e0e84c5747994a5b97e4f2e3d935c2727f7d9e4a64079d7a11f98341b1` |
| test-other | ls-test-other-6432-63723-0046 | 19 | 956415288c8bf740b9b8db8f37e1ce15ab817f88578afe8fb2e744bc0c1cea82 | `bfda596afe6fc3eb093d427611ecc7ccf31460a509a47bdff0993a138ce1e47d` |
| test-other | ls-test-other-7105-2340-0033 | 27 | 92114c1d59b5d0e04984e651dd151729faf41453db2b7dd9bad84ddf04b6ddc6 | `fdda5585dee92acb27acd7846bca23fa0f7335ddd7063edd981366a5bb4e2433` |
| test-other | ls-test-other-8188-269288-0027 | 12 | 042a2cba559599707040b61d71bb8df67fbad439ae2ef02ca43ae18b2cb575c8 | `5f88e7e1b8764f0547c10d5b9e6fd311017fb2f40c26533b7604c12493fc3e34` |
| test-other | ls-test-other-8280-266249-0004 | 17 | 35ada150736b31211d48d52d8f5d96f4aafde1413bb34eec1e865cf4e0551e58 | `dca7f5f533bff7b723b2d5fb4edf3209fb3224c2c05d8bd68c4e98cb59c42155` |
| noisy | smoke-mix-01 | 12 | 87910b29bb221a77c7c49aae0d15a1f4c1a9473281f693bf5024d4b56e62e2ab | `bbc66521b85028e84f21038190bf3af53070824c63908d92cf7fdea7244ba420` |
| noisy | smoke-mix-02 | 25 | b888aff1a8cf3bd2a35cc8cedcf51e7015fff0800587946491ae250e2dfb0590 | `fbee3b6e78a9e37800cdb700831fe6fec68406d79f4caa797a7f1f1f363d889a` |
| noisy | smoke-mix-03 | 19 | bcf0d81630c3e6bc5224d712424e3cea1d7b711ed7f35bfc7a7ae97b34b50b37 | `482f4eac93ef0f87fe1903b448419f669ef1f205de14dc5c150e12dd280b2605` |
| noisy | smoke-mix-04 | 14 | e758403d33ad61c1caa27def162b7e7c6303b3756016c7a6013ce7a9bc3332e1 | `636d46d140698f40de3a066b8d29e717e9ae16ef515b65ba05ea5b47173a5cda` |
| noisy | smoke-mix-05 | 16 | 070d138be7141aeb954c90b79b133fd709a9471b5d07f0371116e2c7c44f476f | `8b9b0be9ab4d0ae052d4456779e76b638de054a7487af01bb5762101983d6eb6` |
| noisy | smoke-mix-06 | 10 | c504300185d5fe7dd696fc1fde33810a22f1973177c97c9f4ff00c80099977ff | `642251d982c08781c33761726bf25a850519fe67e17aa912fbe69695aaa57ddc` |
| noisy | smoke-mix-07 | 26 | 40a2aaa60d1da5489c171a1642ddd15cdc11e92ef3dee6d7c0cff31970c7f034 | `036c939c88b7521c2953ac35fb007ae54de34be7ffe77888034fc3a5b02008e8` |
| noisy | smoke-mix-08 | 23 | 150510b8461a309c5c4c998501060512397fd365cc24b69db00c4ac29c957563 | `b854ed05ab998fe038f0710c3b35e32b68cc99cd3432ed195e82dc383279e5fa` |
| noisy | smoke-mix-09 | 25 | 6a6abb83e505d3353861d315868bc023638ba33dc88d11b2399f732ad49c0c88 | `e8e77101341cefff9e26d80ff23cd672a4e40ec3bc12aa117b083f896db2c921` |
| noisy | smoke-mix-10 | 19 | b37dd1a23cdf37e3bbcadc14374e046e3772400577924656ea82b6c28873391c | `db7b0e02e6c56e8133924215b747f21501e07d54648b73b2b8cd75c095790cf2` |
| non-speech | smoke-music-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `ef68609107f6931863c5c96bd1f74fc4403d0eb5eb7997d8542bcb50f3d524b8` |
| non-speech | smoke-music-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `1116d1294b1cf90367ac6b34865a2727871c8c87580c8588942a6575474076f3` |
| non-speech | smoke-music-03 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `f0922d4adaa105de146a6a7ee19b5f1a11571fcadb4958bb2e51897978793a99` |
| non-speech | smoke-music-04 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `2484b3c96e4bc93c12bbbf0812221d5bb33807e879fefed5b7ab4f5ea5f53338` |
| non-speech | smoke-noise-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `39915043ab9f2792dcaf210e0a16b5934abbbee5546b4e35b5937b8c191198a7` |
| non-speech | smoke-noise-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `80657cd7d73271ccabc2dc49115362bb40ee1c251baff23c8af0f0f179044507` |
| non-speech | smoke-noise-03 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `28cc33ee9adefec123f61ceb026bc7cb5d0778fa7fc0e37001bd25a9a8f2e132` |
| non-speech | smoke-noise-04 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `d8bc13e174e67715b3cf8321efa0b6f067fde74b4dedd494bd7e683c985b5355` |
| non-speech | smoke-silence-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `1df70df38bee17792e9faa33071ff4b1b9454f1bef619613f874f65da99321bb` |
| non-speech | smoke-silence-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `f8744bbf6eabd7873fc4675ac548e972583ad0d268a39d7394d0791d484bdac8` |
| tts | tts-smoke-01 | 10 | 30640fce942d691c56bee86a2c000dfa620f2087b3ae22ec8abfd29c65b1eae1 | `f80bfdc5fedad8401ac62b93d8365f4f5405fcb3874f220b68d385e2e37929fa` |
| tts | tts-smoke-02 | 10 | abfd320d882a8ec2ab888bf778f93eb52b29468e59b83822a313cc0e2881b132 | `6f7035f0eefc29b0d2857106bbdb6b1a2a9a70335a33a4e8ecc79b5bd2860cd4` |
| tts | tts-smoke-03 | 10 | 25174bb2bfba68f128584857466e3aedcfbff528c3f8db91ffb1e738affc996e | `7b7c6d2793fd401678e0c70bb71057d4a3406556a28cfbeae08c4a04f2533d0e` |
| tts | tts-smoke-04 | 9 | cb28d461f9814fb2319952d57cc1019fe6ad9a1b65321c667691c39387880a4e | `94c212f53a080b12fd5ac213841eac8d01731c6a53a7605e6a6e328e23ce4f63` |
| tts | tts-smoke-05 | 10 | de58dde5982f4880069fe246f111f88c13439cd7820235377345fcfcd7eac6d0 | `ecb94b2a4cc42ab207fb558e7147f4e15aa8546c0a18d5b505ad7b2d0432a92f` |
| tts | tts-smoke-06 | 14 | 970e3092763b6055b4e31fd58c3dc4880f6053da1d3fb5eca16374419517a723 | `e1640f54d7918cea0cf3ae0d685101be78096e07978533e5e058cdfad2fd7476` |
| tts | tts-smoke-07 | 10 | 36ecaa833075d36b7382d79b1e10b2e2e3e92f761b443f9fb79c51bc7ded9b39 | `61c85077500ba4e5217afcae36665f7ff40ed26c0a6bfe9f71b5c4b96e0dd7f6` |
| tts | tts-smoke-08 | 12 | 86ef79838b484c35c0ae08df921acae131a03cb554d88ec1e524f86838d2170d | `5d2877e70410f6bb4d5689a0ac40b54c042cf46eb797164bc9ee5d6ee12d6485` |
| tts | tts-smoke-09 | 10 | a00dec41576b4f0fd1291d42ebbcd1c65945a112a2e6fb04df34e92a4d3978d4 | `62c6126be987b96c13547ed81eeda6aff464fbe4bf2cb5cbf6b0a2db9cdda230` |
| tts | tts-smoke-10 | 14 | a91a12354baa65c26dadf08f967e597bdd324308938da754e82bffc5545968bb | `5765eb9f57c9e6684f124b4b7bbbc5e2b190b1123782b39cfa9ddcd15c29bf74` |

## Parakeet offline transcripts (60 clips)

| category | clip_id | text_sha256 | row |
| --- | --- | --- | --- |
| test-clean | ls-test-clean-1188-133604-0029 | d1c76ea36cf22ea32bc429a0bac8a5f2f1c40a7ff230d4b8a6696f6eb333d800 | `53313a666878d056586b49408134eeab2300cde3b59304be24ec6f14c7faa3b1` |
| test-clean | ls-test-clean-121-127105-0012 | 68d729e752d5423d7c2e76de8bf75b8d55fc3ce07d1174ed72ab6797f500db34 | `b503b126ecfa1e3bc36887f3551387ad41f23888d269c3e8b8a586d3b29fc728` |
| test-clean | ls-test-clean-1221-135767-0014 | dc08b223b0786c033d7ca013a2e76b146b17f4b719d6298dc727a4b7cbe98bde | `064679fcb0da106380d1079127dc863be7bc8f73393e1fc99473cdf6a9235408` |
| test-clean | ls-test-clean-1580-141083-0035 | 4bed4b9991e1c5613866117915433e03fdcc49266ccbc1641fae5ee56b86888e | `53073f7363b5f0acb6ed9e957ad0360c343586313afbab0c18a799419cbf1af5` |
| test-clean | ls-test-clean-237-134493-0011 | dcdbc64d0f8497a70fa084a990c7996d41c507d05374877129d3d5c809fdc249 | `edd7a9cbbfcb80e6b93e7ef821ee6fc5e6fcb078b5852a33331529f358d0866b` |
| test-clean | ls-test-clean-2830-3980-0007 | 5b083448d5c9f7822a0b742ba0bb5ea4a413e01b26a14b94380c38093fe784f4 | `fdc6a866ff973449b3e0be680a2307880c20d64107cf9d27e559931ede4fc800` |
| test-clean | ls-test-clean-3570-5695-0009 | 372c74bb4c007dd1b65386597db8384f9e0bb327515ccf7a908e23c8ded75be7 | `c41bf0b648c448ec577cdbf771345af72288ad9e60d0ddc19d9fc77f1d700656` |
| test-clean | ls-test-clean-4077-13751-0014 | 13045dff5dfaf9d56823a23bc6720141122b78e72f2782b5f2604a112efc4130 | `05971ac7abaa1f458916b54b850a1e36f810c84eae15149cdb1098f41f379811` |
| test-clean | ls-test-clean-4446-2271-0024 | a3eac60f7d42cad95c1472d1f12344f2135ab69be59f81f6e86669ffeeac2a51 | `c2f7c46e10ff92d5e4aa1048c603f1e676c3aef80bd144266a2328efa66646fe` |
| test-clean | ls-test-clean-4507-16021-0058 | 331475d475b712286466e562775cc66d53d7b6ebf2e54bb87d48f63d3f77220f | `95e6a427f4a4ca2f241c858fa180897d9be871c47f5dc424804f23b8cacd9aaf` |
| test-clean | ls-test-clean-4970-29095-0002 | f1a80aad29bf8fb66345f5dfec099e7f72640e7072a54afad4a8ca8453b89b74 | `c882e9e0d4ce4cbd2c02969189efdb12b1e096ae9aeffc11f72f3abdd3d0d004` |
| test-clean | ls-test-clean-4992-41797-0015 | 640fadabcf094ad69a72fe746cb4ee960210046fe28351c320a96dcd92917ce9 | `c508ceff9d08c45fe0ed4f1f18b1257c05bb207c5e9e57468244f9575ac11092` |
| test-clean | ls-test-clean-61-70970-0011 | c0e031da2c37d19f7ba120920572f09dda9c9ae8f872280d6fca7578ab11d5ae | `e09cee9e0e9ea935ff8ce18d4b4447e6e2584b869fa94391cf00f81d67b9c875` |
| test-clean | ls-test-clean-6829-68771-0030 | ce74d1a5d44c4a00f51d7280898b279798cd5e862ce0257b09563b90f1e27dac | `1546528f06c35779c7fcd0e887f2759aeb71242b4854151e38b177009d271c32` |
| test-clean | ls-test-clean-7127-75946-0009 | fafe3abe137dbb8a6886ecc87e8115320047aaa3881525f9789f5862a36ada71 | `e92bd77febc912c78a34a569da7d275961cf476bc39c4ffdb6da9bca2445c7d2` |
| test-clean | ls-test-clean-7176-92135-0018 | 99fc12416d4551008716467a5b069c3b6a99896805e35d8edf5ad3787ff0f328 | `22c84c34a01c406e65e21dead9cc31e10c16322e0eb9657f5847554261016b71` |
| test-clean | ls-test-clean-7729-102255-0023 | 8a42eebc3f878181271fc28e02e6aedb54b4622a7d9a048afe3aeaa82257a96b | `a2895e2aee475aa1347545ef7f401433c26703a8207c29a07362f35e9bbc4e40` |
| test-clean | ls-test-clean-8230-279154-0011 | ad50aa1fefbb8d4aa8823b53ca3cc688e9dac6116b0aa7684ee0125642260822 | `617ebf8baf5e8d1053cf6191da7f6904af27f76817226ee6c0c1afe7bf473bb9` |
| test-clean | ls-test-clean-8455-210777-0037 | 634a1ca8203e3cf6bca13a3e03b13ea8583acb09079ce6e8bc7f1b508fe0860d | `4b7c1257f06729f5552c9cf5bb8497481c6bb2e06e3872e49a2c401202d1c95b` |
| test-clean | ls-test-clean-908-157963-0014 | 02fc5351b32f8642488c726d7aadd7406995abf2107e01df8e31864a130b0099 | `52e130427f029893bfc22c9b61a6bc337deba46d1d6d4bb7e10116d522334e45` |
| test-other | ls-test-other-2609-156975-0000 | 2f005507256b3f8c185dea74bb64b160213609db06d4e6ca3347d0cd64778469 | `fe2f266ee04be3716e2ba36fe594eb55d4367b304187656d74e475c305e73968` |
| test-other | ls-test-other-3080-5040-0016 | 4fbbdd9a1874299bbc79e35ff27838d2c2c7a8386cea6baeaa2c5c625f71abcd | `3c07abcd6319895098e7db821f6ede30bc114cf8e68f14adc3d584a37287e8d0` |
| test-other | ls-test-other-3528-168669-0043 | 4b6433fe65cce4f0a529530e63ed925c8af59eb0cb5aa7331e86e2f6ecb6150f | `699c3e39cb33bb2246d078ecb24974c68d4d57baf3e141c8c78c528c01e40cfd` |
| test-other | ls-test-other-3538-142836-0006 | ed46740750361a83547fe4bfc97387c17ae558f94ad4f2dfc33870956e012525 | `0fee430de71322a3c96199ecc5a64bf63fa3a94ef6cebf65db55f1b07173c280` |
| test-other | ls-test-other-4198-12259-0026 | a680d5121ac569762cc6f9b7c6ade161c8b5f390669fcaeda679a683fbacdfcc | `abd8cd93b9185ae088bc62820f5e0f4bf186bd8439bc6530eb3c669175b8c492` |
| test-other | ls-test-other-6128-63244-0013 | f436b925895c6412d41e8bdc0527daa8cc998174371fd8dc7939253441fbadfb | `79a9853531af656024a1769e93c030002a4e144e75ce0a3142487c411050e1cb` |
| test-other | ls-test-other-6432-63723-0046 | 1c2c911e95c438d2873d5de65bb68e761405578b42943317733484f79aabea83 | `a92f0b61808b478bcbe6a755dfeed385a56b630e23a8129cefbd90fdbdc029ef` |
| test-other | ls-test-other-7105-2340-0033 | 64eb42f079a1b415a9300e90e17bb22c9e9010faea4590490b7e4b9d7cd032cf | `fe33338f1b1f3e9a17ef7b015ca9b0fb6b2472075835a432bfcb568df56afe88` |
| test-other | ls-test-other-8188-269288-0027 | b744b832b770124a92be5962b2d8fef51fb366fb0566963ea57b862faa402e38 | `8d3c926c38b4769ce1ce1f195c644ce650f92af6b520d19be202daf80e02ebdc` |
| test-other | ls-test-other-8280-266249-0004 | 7a134cce1231a98272ff91daa64c0e10d9718aa3cdc9c60a34d14092affdc7c5 | `029e7e1704fff4cb771aabe2d109f074cf5855c8ca9bfa8912563562220d97a1` |
| noisy | smoke-mix-01 | 7ab58b0b8c29089541ecf4ba5f832f982e8c48e4dcf514f5eb5362140b8dc742 | `450f2bffeb2ed2050330783e8d3a4848f1249c1dcfbb090d0d1d3b84d7ae956f` |
| noisy | smoke-mix-02 | bc0b290ba694d83fa8c2cc716d5e7c0e5825288da0f89c1b668b035f456b5104 | `dc79afd4cf0f06f2ee2aebd833f84653e5f907b43339efc53f50a82ccfe65ac6` |
| noisy | smoke-mix-03 | 7fb4b83d2fc6eb303b309fa0fa554054e3c1991dfcd046545fff0695b29fdbf2 | `99817a39b710f7306321e53a28a12c2b438d50fdfc2990126cafa6f606379293` |
| noisy | smoke-mix-04 | 75fb1fbecf484c9d0b438cdc4788a56784d6983e38074b81cfbf5815883e4cb8 | `9a44e66e8eef2b4235a631854587aca21f248e594d2ea7ce1f9442aaf7fcc69e` |
| noisy | smoke-mix-05 | 08bd9b3a5c20f777c10e9be00bf6696e5b50a51755be897e762e4d4993836f8e | `289b3f63572fa1b8f93a266a56218f02e8d3b17e250c207844fe33892a543e8d` |
| noisy | smoke-mix-06 | 4127a6350bc9e5cad3db3ed83263bc1d27d5b6f244bd3ea1c172501cefba9f38 | `1316642102e201a1d9159588a4aa538541b589ddd60a087cb1e73385f6a994bb` |
| noisy | smoke-mix-07 | f4ff0e0a6071573f0a66f842c4b8dc2976cb39194a20d9fce882846cb7f978db | `7ee0e2458768441e1360ea3764dd3e6a821465898ad3efba4781c90dca81b73e` |
| noisy | smoke-mix-08 | 35e4d1ec1dc56116bc5dff234c8ae600c725f0e8a74ea562e3e038da049b2991 | `128ac67900e17d9e4d7aec6324726710eb84265616f6cce03fc7d748c2cdd462` |
| noisy | smoke-mix-09 | 6805268231cdd4572584fc0b9ef6e0ace0730adbfbe99243dbf214efa3681367 | `69c3777723449842fe856a580070ab808b29c2f97f0eb59ce0ea601ba48cfb5b` |
| noisy | smoke-mix-10 | 242c44309d13873819bd8b915142b8a34a120b781e93d76ba5e205507213adca | `37cd6703f4706996005b6aff22decf9a36a3c54f8f3a92ac057fa94d1c4e08b7` |
| non-speech | smoke-music-01 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `e34703e9a2b7c0f14df5e2654e7f51da5454a6d1ecd0295068fca62e52139885` |
| non-speech | smoke-music-02 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `ac9fe1a276ce2f786be9210ab424fdbe0600a053044b0a01cbca3083957a61cb` |
| non-speech | smoke-music-03 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `080a54d4fe77e512bf37dc28d88c1601a927e2e86c4d9a698625c7e8ce2f8273` |
| non-speech | smoke-music-04 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `66db094f5fd8b61aa0351f6350606726aed22089042980493be904b86fd16678` |
| non-speech | smoke-noise-01 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `a27400a46da9147170c0f121f42ab013f5ddec1cfc69fabe2feb8a1b2ff0f1f5` |
| non-speech | smoke-noise-02 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `1422b0075ff5b191243109229ad0dd16c7bfbfd161c1b008b7c9604f7f78251f` |
| non-speech | smoke-noise-03 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `462a7d01601cb33b750fc0ac2f1524f8b9bb62a4654062b85a54b3bc2688e62e` |
| non-speech | smoke-noise-04 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `52d476c61928498dcb799b50c032b49f9455643880a5d1977f483d05419ef1ff` |
| non-speech | smoke-silence-01 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `8b9ef03a7c59b184e7fbe3d1deadd4525fca44d391ccb3575a729d7160a53e71` |
| non-speech | smoke-silence-02 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `5daa9d0202314e5bafedc0e5190f098cbf34e7ce8606005896417a40e68ca62e` |
| tts | tts-smoke-01 | 84d89877f0d4041efb6bf91a16f0248f2fd573e6af05c19f96bedb9f882f7882 | `556eca89a8618c0bca3b2e06b89162852e068b011e61584e908fdd5a4905d7cd` |
| tts | tts-smoke-02 | b9693ec1334f9e24e39a7d65a490ae72ccf0eb17fc9e99ee4b337773ba46e693 | `20fee5a4e40f911226a4fae421d893743e30572b2d1581f4472c0fa499938724` |
| tts | tts-smoke-03 | 7619ee8cea49187f309616e30ecf54be072259b43760f1f550a644945d5572f2 | `f4cc11ba57144b829b58ea6f38218b9bc2e363fdde8f0421d42df8f47079f519` |
| tts | tts-smoke-04 | aae92c693767a1dedccbe85fc0d81b969f02c484c19c21e8dfeaeeb47fd3c753 | `57b0a8b9870b4072a8d7835459f765799e9720aa189e8661dfad4cc861637af0` |
| tts | tts-smoke-05 | e60ca3d925d99b5ea4e705d6ecbaa3d17afb7fd5ac4da0aaffec5dc9786bad0e | `8585bb964bec4ef8526a8d5780ce6f105afc189a9ff3ca5d15817e7181871f75` |
| tts | tts-smoke-06 | 7370a823e8962099005fa8cd7707b8baceca15864044326b2210e8f0f6977a72 | `59e42a629cce40b68b47b542e7a6f3831742be190cce17d0385d0a3a460ff5a9` |
| tts | tts-smoke-07 | ae616480a1f36b57b54a83055dc12fa6f5e59dc2c3feee519c3aecf11fe0c242 | `46952d0d0cb788bb9091e0a13cd09e53a3c818c628b4d5e0be3bd06723e40762` |
| tts | tts-smoke-08 | bc2e8b38fafe0c4d9d6b76a148b62bf914fae4802906e756a2663a2a5b5542eb | `1d339aca0a590aa1ca01820de882a6fb835872aafa9df3f31c649e1789b4c262` |
| tts | tts-smoke-09 | 8519f82dd9c9c82320901d94f8d244ec4f028f3cbaa5ba4e104cc6972a16d766 | `f6b5382fd8f196d9a032a700ac80e3973006fed4d0d9c763504f484981a231de` |
| tts | tts-smoke-10 | 8c4cdc7c36083989fc0c1e90010055ee2a14892cd2c6d05a3a10824ec6660d44 | `0eb58b73b237e5acf91ee2641e2dbfcff83efd3aff2e90aa4392317169a1264a` |

## Real-speed Vosk (20 ms frames, never faster than real time)

First-partial latency: first partial event minus the delivery of the frame holding the first recognised word's start. Finalisation latency: last final event minus the audio-end mark. Both in milliseconds (owner decision, question 7).

| clip_id | audio_s | first_partial_latency_ms | finalisation_latency_ms | max_frame_lag_ms | row |
| --- | --- | --- | --- | --- | --- |
| ls-test-clean-3570-5695-0009 | 5.0250 | 216.9053 | 30.8932 | 296.4956 | `777d0bb3c238a983bfe813a96af5cd0bb29350d97446019a0beaf418aef237a6` |
| ls-test-clean-6829-68771-0030 | 6.2250 | 587.4114 | 39.2236 | 134.8856 | `5148fc56e74aaec3ec40a32c308d6ac7786390c768508e499d9804eb12041e06` |
| ls-test-other-6128-63244-0013 | 4.1450 | 727.6461 | 40.7356 | 261.0179 | `630f6719f4642c8ded5bba175d7a83322177f91eebf457e49a96f549bcd1297a` |
| smoke-mix-01 | 5.2250 | 436.1502 | 15.7976 | 204.1552 | `dcdd481d14b9f1bf39b2a17eabf167ab5aed05a7d1e65b2defc7920a95f6758b` |
| tts-smoke-04 | 4.9750 | 816.7170 | 16.8415 | 301.4447 | `0f20976980cb0a027b68307967b0e6f7b81d6ba70cdc099d87c6a59968bc8513` |

- First-partial latency: median 587.4114, maximum 816.7170 ms.
- Finalisation latency: median 30.8932, maximum 40.7356 ms.
- Real-speed transcript equal to the batch transcript: 5 of 5 clips.

## Harness VAD (webrtc_vad_mode2, 20 ms frames)

| category | clip_id | speech_frames | speech_s | row |
| --- | --- | --- | --- | --- |
| test-clean | ls-test-clean-1188-133604-0029 | 115 | 2.3000 | `fd9577c399901496747a6586dd67c36ac2bd210744350ba7815e89f8c2f5e083` |
| test-clean | ls-test-clean-121-127105-0012 | 227 | 4.5400 | `ed5dd1834a6b62cac81cbcfea6eb123a9e2436a0f8af90ca8bcfa2654f27d350` |
| test-clean | ls-test-clean-1221-135767-0014 | 315 | 6.3000 | `c585938e71bbc212d35973ad21bd5fe184ca7c618a19f3d440447e9f844a5503` |
| test-clean | ls-test-clean-1580-141083-0035 | 212 | 4.2400 | `35c9de71e0b8d5e0fbacc5983469d191b240801e942b561890ec03648f0745b1` |
| test-clean | ls-test-clean-237-134493-0011 | 238 | 4.7600 | `f3afd1b56de47587612b9b29d262e5ed7f8a41d3c4062eaa721d66e0878701c3` |
| test-clean | ls-test-clean-2830-3980-0007 | 430 | 8.6000 | `766ea6883ecd596f4a57abb2b0ab899e66d2594871b14236f6e82a847f896fde` |
| test-clean | ls-test-clean-3570-5695-0009 | 221 | 4.4200 | `a7b1216d31f01889de407a86eaf0cae0d0dc758c1ff1070c9f54037fbebfb5af` |
| test-clean | ls-test-clean-4077-13751-0014 | 595 | 11.9000 | `1955d95503762a5150743d04de6c2db5114d0d33ebb79dab1384ba41c1a5b913` |
| test-clean | ls-test-clean-4446-2271-0024 | 133 | 2.6600 | `fdc7f5a65e5ea785fa1d18743d6bb05709bcdaf8c97822a33835e7303c96836e` |
| test-clean | ls-test-clean-4507-16021-0058 | 122 | 2.4400 | `6d5621fa7db93416e35bdfca1be322a1153a0f3bea846092f55dc4d781b32964` |
| test-clean | ls-test-clean-4970-29095-0002 | 217 | 4.3400 | `33f28c1d357d0bd81dfb1533fc45868d594a07f2154a788c419b4de77576ae3d` |
| test-clean | ls-test-clean-4992-41797-0015 | 380 | 7.6000 | `cdccbd7e260e226dd34fd67da97e1c33c7e971a61e04792fe8fe1e8d46cd05fa` |
| test-clean | ls-test-clean-61-70970-0011 | 273 | 5.4600 | `88766bcc1e85674ca4c6a8dc65351d4480e9a40f58d76ec76909f35f8540fb4d` |
| test-clean | ls-test-clean-6829-68771-0030 | 295 | 5.9000 | `fddca7353017bb14bdc586708f9a0227ca22019c37b573b9812c2fcb10fa4fc9` |
| test-clean | ls-test-clean-7127-75946-0009 | 198 | 3.9600 | `84c1a0d90998788b749de1100162d435e0905c9c62f6badc0e983d7bf7655c8b` |
| test-clean | ls-test-clean-7176-92135-0018 | 419 | 8.3800 | `8b5be1c7f7c123a1fbbdff015dd0b3ca7129fd6a2fa7f3b2421c1c5b84fc3548` |
| test-clean | ls-test-clean-7729-102255-0023 | 260 | 5.2000 | `d2ffdc2696975cb2a73661751c53780ead9e28e8c3625feb34f23f63fd7d503c` |
| test-clean | ls-test-clean-8230-279154-0011 | 282 | 5.6400 | `8ae8c8d11a44a8abb9ae37fec088b7697c992ec856e1c5b0282ea5709cbaf39d` |
| test-clean | ls-test-clean-8455-210777-0037 | 170 | 3.4000 | `3d768e278e6f3fb2450c35f11f1241abe0b650c4b352596fbf6fb1ff7478e6e0` |
| test-clean | ls-test-clean-908-157963-0014 | 199 | 3.9800 | `a3caa8d3bbb64bc9c4a992862c574fd8dc1c41f2d3123e49953e87cfaaf33b9b` |
| test-other | ls-test-other-2609-156975-0000 | 176 | 3.5200 | `c638426369d1ab95c259db83ccb1ba9846e017ec7bb27e363b3220f15b1a41af` |
| test-other | ls-test-other-3080-5040-0016 | 218 | 4.3600 | `1811948327b140fac3bebbae43149f21bebc49e9a0976b0f411d2c3b1813d6ec` |
| test-other | ls-test-other-3528-168669-0043 | 166 | 3.3200 | `3ed82f5cd586c2c8a99edddfb30f12e57448f64fd4b7219835fdd2ae181ef19a` |
| test-other | ls-test-other-3538-142836-0006 | 235 | 4.7000 | `a760ee6961092fc175e2bb2f86426fb3645e7f8991f7de8e988093fa5e805404` |
| test-other | ls-test-other-4198-12259-0026 | 214 | 4.2800 | `aa70d24447ea73277c770ead37f4836fa37e5bdaa1e4db3be9dd2c337bb0a3cb` |
| test-other | ls-test-other-6128-63244-0013 | 180 | 3.6000 | `ef740018fa79ca59b568fc06e261e53c9e8681f377af38ac9be69204657dfc8b` |
| test-other | ls-test-other-6432-63723-0046 | 272 | 5.4400 | `6d28c503a4178c45f4f4389922b6960d77417909c62bd4f5f99e59a3a6f88422` |
| test-other | ls-test-other-7105-2340-0033 | 471 | 9.4200 | `f950265e6a316c756cd9e333cc9c7a2a887a0f12a27e4dca564c52e4c976bdb6` |
| test-other | ls-test-other-8188-269288-0027 | 160 | 3.2000 | `0bc80b5f6a693f00d0ade2a0de06771a023c3f98ceac6b09bdd139092f81e11f` |
| test-other | ls-test-other-8280-266249-0004 | 240 | 4.8000 | `c3a816fd5ce702cebe479494415e956400e090c5ade7cde957222f7187039c4b` |
| noisy | smoke-mix-01 | 260 | 5.2000 | `0df1e2098120755c2047ff19f4693ba896f573fc5468e6247f4b53955ea5467d` |
| noisy | smoke-mix-02 | 463 | 9.2600 | `f3bd40a1f7bf2693290a5c666367d2291fe6b62fe953be38ff30158a6ba58cf9` |
| noisy | smoke-mix-03 | 370 | 7.4000 | `47f97eed355a98bc89ea90a77dc8f9709da7ed3be8713e4561a59b7f018d7184` |
| noisy | smoke-mix-04 | 253 | 5.0600 | `d73035b51baa71f419f45f94e4ba1b20e7d0fd0ef091d189f82120ca18ebfa87` |
| noisy | smoke-mix-05 | 302 | 6.0400 | `c183128bcfd772f323ab88c0908cc3c830a99a3522823c9ac4e912bd883a0bc4` |
| noisy | smoke-mix-06 | 156 | 3.1200 | `2a60d83ec727e24622623a95e5a0533e679ec999d94f60b4bd5f0ceda297a341` |
| noisy | smoke-mix-07 | 446 | 8.9200 | `d91356dac976483527a2b8c739e3a9be773f96114d9cfd6e7fa78194017f8fe9` |
| noisy | smoke-mix-08 | 341 | 6.8200 | `c754402a637d42f0e767cb8cb8d2f71edcc7ba06208c620104e9dc8d9610bba0` |
| noisy | smoke-mix-09 | 379 | 7.5800 | `e2239733b2beac722cf7893e1b4271fffce1e048ba666c0c520912669e9887e4` |
| noisy | smoke-mix-10 | 330 | 6.6000 | `7c290f3ee6dd6b71f1d0b77c7cd78012663eb05a29325541a4ec4d3a38bc8c30` |
| non-speech | smoke-music-01 | 490 | 9.8000 | `e593342af44f5c6fe38acfdee27fc577852481390e0b038c57d07a28a9564d4f` |
| non-speech | smoke-music-02 | 500 | 10.0000 | `97dc7e82645cb7d2090d2591feb3fd0f6862cc4de767a5df08099bfc3e62af39` |
| non-speech | smoke-music-03 | 4 | 0.0800 | `bbc2205f9251c79d1256ff709154d763cf22b5dd207402c752c0447dcac5fdda` |
| non-speech | smoke-music-04 | 500 | 10.0000 | `b6fb5b0fed3de62ad2efee2b0ca2bcf832fe3fa753aa5ce3e1e6d16c6386df26` |
| non-speech | smoke-noise-01 | 117 | 2.3400 | `6bb664382c740005c13adbafcc4107b284922c0d9e5692cb09ad8fb42fef97a9` |
| non-speech | smoke-noise-02 | 500 | 10.0000 | `bdce46408bcea2a221ddea0294d65df7963367a89fc5ce13a5c6fe84e2ceace6` |
| non-speech | smoke-noise-03 | 260 | 5.2000 | `4c5b3b22f13665e552ed6f6ee17273b03cb64d4d0a22d487fc86275952178249` |
| non-speech | smoke-noise-04 | 8 | 0.1600 | `c3ef801af78f87d595607c447e48cb9d5adcb04e2fbf01084382408fe0026f73` |
| non-speech | smoke-silence-01 | 0 | 0 | `f7da8ae4334144922445a849a6d81477c41a0d7454029669da75000c1ad3d988` |
| non-speech | smoke-silence-02 | 0 | 0 | `5339cbc5238c90069a3664ee85df4874d223de98dc778e67a9fc51cc2a75cd7b` |
| tts | tts-smoke-01 | 134 | 2.6800 | `30eb67b31e25faf3cf1848aa11919cd5fef6fe879703d349c2339dced1fb1535` |
| tts | tts-smoke-02 | 167 | 3.3400 | `e932de949f02bb7a538a09fc2d83b1b55d28539e68f9ce63035ed6602721f21c` |
| tts | tts-smoke-03 | 141 | 2.8200 | `768c1e18da626b3b6d7fff824aa1edd41a19b4befdf8e2d65a22854a8fe82f44` |
| tts | tts-smoke-04 | 168 | 3.3600 | `e42d8c41713f9241345b57f3ad1a3ba77e082be356cd649b37b81603fd92f1a4` |
| tts | tts-smoke-05 | 143 | 2.8600 | `bbad4af694158464d73f7fd7cb1e5a822fc7c779fffff558c2a5fd0076ef7ac9` |
| tts | tts-smoke-06 | 156 | 3.1200 | `bcd2a61329e4a6a7d43c1d81b9275080765eaa89e7de2f96ed63ccdccfc82af8` |
| tts | tts-smoke-07 | 145 | 2.9000 | `508f7b6aa323b16150928cf1823e34ca37337a75b20b77775a8a8a6338b20487` |
| tts | tts-smoke-08 | 185 | 3.7000 | `86ec8d2ff4e85372dca7efd224118f19ba125c60c2ed60aa8662d7f58659e37b` |
| tts | tts-smoke-09 | 136 | 2.7200 | `5de1a86693ce85f33f08f79619c055bd0513c4e6c90143d91757b30781aa5a7f` |
| tts | tts-smoke-10 | 145 | 2.9000 | `4831c55ea2cbfe5f1a20e8f7c3af2adf36c6c63c8dde8704a6e06dd1f6961aa4` |

## Parakeet GPU compute delay (one untimed warm-up first)

| clip_id | audio_s | processing_ms | rtf | gpu | row |
| --- | --- | --- | --- | --- | --- |
| ls-test-clean-3570-5695-0009 | 5.0250 | 129.5899 | 0.0258 | Tesla T4 | `8498b7bf9f6b5c146c2368fcc51cb45236b8a6aa101c163ec2a4c2155cbc4489` |
| ls-test-clean-6829-68771-0030 | 6.2250 | 162.3672 | 0.0261 | Tesla T4 | `6273a0169c75332969d5de916be56d76029e4f9b82fa586744b4314678812f01` |
| ls-test-other-6128-63244-0013 | 4.1450 | 117.6548 | 0.0284 | Tesla T4 | `8c7a0c40a6297e927e0c1c1394d44a2905405b8af43760f5267e1ac287cb2ca3` |
| smoke-mix-01 | 5.2250 | 128.8635 | 0.0247 | Tesla T4 | `7a7318faaa396d37fe7083d902a34b225eddb230225e2e55f8b56db24a2f2e36` |
| tts-smoke-04 | 4.9750 | 106.1279 | 0.0213 | Tesla T4 | `4ac86667553a7b6b9577c2eec59492d48874a8b209218ca1da45e6afeaf0713b` |

- Processing time: median 128.8635, maximum 162.3672 ms per clip on Tesla T4.
