# Phase 0 smoke run: target oracle

Bundle `phase0-smoke-oracle-20261002T141937Z` (bundle format 1.0, docs/runs/PHASE0_SMOKE.md), written 2026-10-02T14:19:37Z on oracle:jitsi.

- Machine: platform oracle, Neoverse-N1, aarch64, Ubuntu 24.04.4 LTS, Python 3.13.7, GPU none.
- Code: git commit `7c27dd53e670d1a207be8738873eeb22bc1ce968` (dirty: false).
- Locks: `requirements/aqis_lab/phase0.txt` sha256 `87a1cc34c6d41388cf8ce1e415f95f61c3b24a7bc45b69a828a957c1813fdcef`.
- Elapsed: 116.1602 s (NFR-0.7-01: at most 900 s on the cloud VM).

Every number below is printed from a file of this bundle. A table row names its result row: add the bundle's run and score folders to a results store (`python -m aqis_lab results add --run runs/<task>`, then `--scores scores/<table>`) and run `python -m aqis_lab trace <row>`.

## Runs

| task | run card | mode | clips | results.jsonl sha256 | events |
| --- | --- | --- | --- | --- | --- |
| vosk-batch | `24f9e3e1e4d17f1fcd37f2e2c0ea84bdbab0cc801f4a6b9a2ef46d65466dc537` | batch | 60 | `1420bad59794b6e33ca6bff91e2a94895fab536876635b180a801fb0d0e8071b` | 894 |
| harness-vad | `071e90050bb0573794f65bc2f563a028d9aad3559f779f5a324fbf869d6b42ed` | batch | 60 | `0bef22237eee7e87435111b8a4ce87a816e32ebad2391842a4751905b97823c4` | 462 |
| vosk-realspeed | `c77a2feefa83ffd7b7593601c2e317d9ffeaed49818997fd12b17210723dee7f` | realspeed_cpu | 5 | `b4c056ec8b62af06ef3e7341be5213e4c6139cecbc36fe1c61e48816df25aa48` | 81 |

## Word error rate (WP-0.3 scorer)

Tables `*-synthetic-tts` are synthetic TTS speech: plumbing only, never a model judgement (docs/data/SMOKE_PACK.md).

| table | variant | corpus WER | errors | reference words | corpus CER | summary.json sha256 |
| --- | --- | --- | --- | --- | --- | --- |
| vosk-batch-natural | disfluency_aware | 0.1074 | 74 | 689 | 0.0528 | `935c77416e18bdec42b6285b436b126abc2c0495dcd9e244284a44a8c9632f23` |
| vosk-batch-natural | main | 0.1074 | 74 | 689 | 0.0528 | `935c77416e18bdec42b6285b436b126abc2c0495dcd9e244284a44a8c9632f23` |
| vosk-batch-synthetic-tts | disfluency_aware | 0.0476 | 3 | 63 | 0.0115 | `bc09907b715ce2a2acbb9960dc4ddcaaba837a694a7d31f020640fdeab2076d0` |
| vosk-batch-synthetic-tts | main | 0.0476 | 3 | 63 | 0.0115 | `bc09907b715ce2a2acbb9960dc4ddcaaba837a694a7d31f020640fdeab2076d0` |

### WER per clip (variant main)

| table | clip_id | wer | errors | ref_words | row |
| --- | --- | --- | --- | --- | --- |
| vosk-batch-natural | ls-test-clean-1188-133604-0029 | 0.1111 | 1 | 9 | `1561559d339dd4f417d537097b40735343cd405cc9e4ce70e96619aff97b4388` |
| vosk-batch-natural | ls-test-clean-121-127105-0012 | 0.1429 | 3 | 21 | `93ac1b71cf38930d7f9088dc56f0bc0c0dd88ee394d084ae7caff043e13cc425` |
| vosk-batch-natural | ls-test-clean-1221-135767-0014 | 0.0500 | 1 | 20 | `0396f913ff995f95ae267ca25ae754d92707c1a7244e0522ab8e154a51b27f0a` |
| vosk-batch-natural | ls-test-clean-1580-141083-0035 | 0.0769 | 1 | 13 | `1c5745409c16c4fdbcf56cc2e1965911be2e2c0b552efe7c5e7897c8c5d10b8c` |
| vosk-batch-natural | ls-test-clean-237-134493-0011 | 0.0000 | 0 | 19 | `f25e31124704048ddaffe0c5785d6ffda2487380bb1fb09e907fb4f5667d861b` |
| vosk-batch-natural | ls-test-clean-2830-3980-0007 | 0.0909 | 3 | 33 | `28a59081303f8823441c4dc3c53d994c56c35990595a5cd02c31873c0361e4ed` |
| vosk-batch-natural | ls-test-clean-3570-5695-0009 | 0.0714 | 1 | 14 | `5a11ccecd777ab764be3cc17aaef56cc0c73e5d0427a9214c2d583d369d7cb33` |
| vosk-batch-natural | ls-test-clean-4077-13751-0014 | 0.1471 | 5 | 34 | `563ff0d0761a229a588a03ed52180140311f92d25f70c555497d14e4ec9513cf` |
| vosk-batch-natural | ls-test-clean-4446-2271-0024 | 0.0769 | 1 | 13 | `a93971a4e833450cc4cbeb8700bf85a0e5d817f25e8a720914748f835b5dd2aa` |
| vosk-batch-natural | ls-test-clean-4507-16021-0058 | 0.0000 | 0 | 8 | `6673ec5fa813cbb85fa31c93595bc5d13d7f4345c3c3b64b6c94cf13311a4506` |
| vosk-batch-natural | ls-test-clean-4970-29095-0002 | 0.0769 | 1 | 13 | `6b33ff7368d273b7cc4da2416d11f59a6178c2693c93d449160827edf789c8b7` |
| vosk-batch-natural | ls-test-clean-4992-41797-0015 | 0.0333 | 1 | 30 | `0dcb1536da5a1be38e27cbb6bbffc92cdeb35e76cf323b6812169bc4a6ca8cf5` |
| vosk-batch-natural | ls-test-clean-61-70970-0011 | 0.1333 | 2 | 15 | `7db3443fb2ad4e0f4350398a1451ff849ed68374b0af9a7318a9e82c441bd861` |
| vosk-batch-natural | ls-test-clean-6829-68771-0030 | 0.0000 | 0 | 17 | `902449e27a0d018e89a4d24e90ac16ddbfdcd86eb885a74a530a08d4473d9d2f` |
| vosk-batch-natural | ls-test-clean-7127-75946-0009 | 0.0000 | 0 | 12 | `7f57868a0c95b4d6d7ad9f55806a3f3c50f7ce769a711c767a43059545dccd5c` |
| vosk-batch-natural | ls-test-clean-7176-92135-0018 | 0.0370 | 1 | 27 | `62471278084c4484359b3a6985b9029a920025cf83d9ca63c7b5172910727464` |
| vosk-batch-natural | ls-test-clean-7729-102255-0023 | 0.0000 | 0 | 10 | `edbe243d4a592371d4c6a5c4423af5aa562c87dd96c7b5ca3fed599aa1125166` |
| vosk-batch-natural | ls-test-clean-8230-279154-0011 | 0.0000 | 0 | 12 | `394af73af782ef485986e0a5b1c99d95398e6a701907d9a7743e023d714ad99e` |
| vosk-batch-natural | ls-test-clean-8455-210777-0037 | 0.0000 | 0 | 10 | `2773004ebbbfb4e1c9f4a991156112d66144cd1c1c924a68fce6233579ebfb33` |
| vosk-batch-natural | ls-test-clean-908-157963-0014 | 0.2727 | 3 | 11 | `4f42305e17ed17b8b95073dd366c64cc73f7cc544cf158afbe1e042cd03fd4d0` |
| vosk-batch-natural | ls-test-other-2609-156975-0000 | 0.5455 | 6 | 11 | `0a3f1ad1396640486bec983cb524e5b23e74f2bd8c2a16da072c5f5f75a3e776` |
| vosk-batch-natural | ls-test-other-3080-5040-0016 | 0.0526 | 1 | 19 | `aee8e2ea71fdc2f414268d2ad842a8e8670714609941be9d2bfd03a802e814d8` |
| vosk-batch-natural | ls-test-other-3528-168669-0043 | 0.3000 | 3 | 10 | `e2b2011848878b574528e9695892157bf8ab4ca2818bf30e22064d79ec696e16` |
| vosk-batch-natural | ls-test-other-3538-142836-0006 | 0.0000 | 0 | 18 | `2736a0ffe66d23417c31464b04b7f648b78437bd54cc49674cefc206e8d485a8` |
| vosk-batch-natural | ls-test-other-4198-12259-0026 | 0.4615 | 6 | 13 | `abf51c6e2b3033c90e5177407181a0dc5a44172f119de7b8ea21c8b3c34ad625` |
| vosk-batch-natural | ls-test-other-6128-63244-0013 | 0.6364 | 7 | 11 | `cbcbbb1d2a93b4190cb9beb6c0e4f6666513cc87d315788c4e359042482a318e` |
| vosk-batch-natural | ls-test-other-6432-63723-0046 | 0.0000 | 0 | 19 | `2ff071bb3fef72f7c24110a8399f4fc9db88703089eee7945cb314fed4fb9bc3` |
| vosk-batch-natural | ls-test-other-7105-2340-0033 | 0.0000 | 0 | 27 | `99b5c5bad6978753a3cf53a6c7cb8755779324072d5a49b0bd414e1cbdd6f02b` |
| vosk-batch-natural | ls-test-other-8188-269288-0027 | 0.1667 | 2 | 12 | `5f547130e247abb8484dca97885e57049d55e06d9498db8b128ebd4ff816523d` |
| vosk-batch-natural | ls-test-other-8280-266249-0004 | 0.1176 | 2 | 17 | `f2ec6ff98e9a76a534c1a8d76882fa3da440b2a5cb431667cdf5872d90a81623` |
| vosk-batch-natural | smoke-mix-01 | 0.2500 | 3 | 12 | `25939dd6b3f739d1ffa71246a89e63233e3da23408db4bb7f1a4f57a915b7116` |
| vosk-batch-natural | smoke-mix-02 | 0.3333 | 8 | 24 | `59d610fac50be2d28e64b41024611194b0f58b9a070b56d6a3cb261af96d457c` |
| vosk-batch-natural | smoke-mix-03 | 0.0000 | 0 | 19 | `956c90df74e8bbbd34f77ce1417d12de285c3dff4fadc2a2c3b11d4f895650b9` |
| vosk-batch-natural | smoke-mix-04 | 0.0000 | 0 | 14 | `a99622654b4e1bdc799732602f036ec46d90f0339a7965e142810038f4df6447` |
| vosk-batch-natural | smoke-mix-05 | 0.0625 | 1 | 16 | `d7202b09a896260603e56691a5e39f3fc1206ddb00af0a5ac2cff51f20615d8f` |
| vosk-batch-natural | smoke-mix-06 | 0.2000 | 2 | 10 | `19814967c811c7a7da0a59bd15e8c2a617c96c70084dd552e0cc3df212484a18` |
| vosk-batch-natural | smoke-mix-07 | 0.0385 | 1 | 26 | `47eb77e605ff51d489475f30d141e41f1f1ff78a009b4467d797f70892bec947` |
| vosk-batch-natural | smoke-mix-08 | 0.0870 | 2 | 23 | `5519d67460fa86489583a547d9250c09d9f87d006b318a4d40cf2c9c64f627ae` |
| vosk-batch-natural | smoke-mix-09 | 0.1481 | 4 | 27 | `93d72a1b9b532ca58105c0ebc696d8969c1ae63e1add3d228f4ecb0ef470e223` |
| vosk-batch-natural | smoke-mix-10 | 0.1000 | 2 | 20 | `1fc5088d66e29e80b8cbb47d9692d4f6ab24a0cc451d30dc1874c26151aaa048` |
| vosk-batch-synthetic-tts | tts-smoke-01 | 0.0000 | 0 | 1 | `6c8a735ffa0211f36f7caae701b50686cc63dea1e4125bff709e525b66b44f3c` |
| vosk-batch-synthetic-tts | tts-smoke-02 | 0.0000 | 0 | 10 | `79d364a0379f230ed2328f76fef6485cf2f5f53928faaf8e42c5205342b60146` |
| vosk-batch-synthetic-tts | tts-smoke-03 | 0.0000 | 0 | 1 | `e73ae472e83425501e01ee4f657b8970e9b8537fca54984d8b57f7928740a157` |
| vosk-batch-synthetic-tts | tts-smoke-04 | 0.1111 | 1 | 9 | `a7b6f080a17c1310e31064fccdb1cc1d9fc4522dc1b2f5051e7bd6ed806e027d` |
| vosk-batch-synthetic-tts | tts-smoke-05 | 0.0000 | 0 | 1 | `7519cd4375a8fc07e38a3e0da0d0d2f4533e6767d12b1f873d6e2aaa35d5306a` |
| vosk-batch-synthetic-tts | tts-smoke-06 | 0.0000 | 0 | 14 | `028c8a4d6cdb35b91511ffb26afb1f54d3eb52322b98f179a0e3996e541efdc9` |
| vosk-batch-synthetic-tts | tts-smoke-07 | 0.0000 | 0 | 1 | `6354dd1db445929651dff7998d6cf32757385167d9050e5b8a3bceeaa8ae4163` |
| vosk-batch-synthetic-tts | tts-smoke-08 | 0.0000 | 0 | 12 | `93ba7cb086b06de28a8e794bb6ae78be19a287390b770e600100095ac7924b03` |
| vosk-batch-synthetic-tts | tts-smoke-09 | 0.0000 | 0 | 1 | `9797e4de79b1f01197ab44bbc8d7f68dcf60f4409b828dde73eb845d23dbe209` |
| vosk-batch-synthetic-tts | tts-smoke-10 | 0.1538 | 2 | 13 | `12e83111217f62ce7d0cddc236a564f9b80f89a2054326ceb95848f70d0950b3` |

## Vosk batch transcripts (60 clips)

| category | clip_id | words | text_sha256 | row |
| --- | --- | --- | --- | --- |
| test-clean | ls-test-clean-1188-133604-0029 | 9 | ed0cdc46462af3fd85466e4075531ee6d435532e1ec02e0590bba2cf4537a288 | `d2df021bd6f79eb30d038911462e2f556732355d73417418de0b2df6b07a46f3` |
| test-clean | ls-test-clean-121-127105-0012 | 18 | 699ad819bfcf8b39789087c3f0b15bf114c1c75b75f6e8ef6f0133c9ca259a29 | `d81ef1c659cddb56c3c8d782c122f7ce21e15bfccf4c896623facabe4e84209f` |
| test-clean | ls-test-clean-1221-135767-0014 | 20 | 77eeb5c74e6a837f48d06d5d1c6e82e20d660dfb2f67893eb1545cfb971a1f5b | `2fc78834859e490315d1c96245d89595b70262813d6873c2543db513ecb54890` |
| test-clean | ls-test-clean-1580-141083-0035 | 13 | 7ed7925898bfabeb4443421409c639975eb0d4b8e1e5791df7871786d038e48e | `54a975fb36287dcaaa30543d8d469ed1ffc5f221f4c10839a33f07c0616001f0` |
| test-clean | ls-test-clean-237-134493-0011 | 18 | cd082978af6d92788438beec92e61403187c2a8d86ce1802c07fb22976191948 | `90e41c7c90bc2f31ee178c29b9a7e10294f5b3ed4dba5b6a6e53ef4abf0ed108` |
| test-clean | ls-test-clean-2830-3980-0007 | 33 | 36af36ac244f4016d204bd3b991eb497bf48a15378c9434b726cb95846437cce | `bbd780863d5b698a1557df797f626e38de9bc4f5c3d8f52ab6b02afc504921bf` |
| test-clean | ls-test-clean-3570-5695-0009 | 15 | cff865c42fc22044f4f00219966c7fa5ff6d5718c9ff254e632e78630becf5a0 | `972c97027ebfb74c8f6b0c25d86779881882ef5e1f9bd1ef877da13735af0bbc` |
| test-clean | ls-test-clean-4077-13751-0014 | 36 | 79d2318af8535b69de087760526f0ec46274301bf72765f91266629cb4b3be9c | `4903c220b968eb486f2202a27f32384f6bed6033edaa899ff881153d1dd48463` |
| test-clean | ls-test-clean-4446-2271-0024 | 11 | 74d466a6d2a3cd1a476bb21b1227a108c9f342eeed7caf78905599b9d01fa9aa | `05142def7ee2080352a7f24fb3eaf7fa87d8eaeae8fc8c63e0aa89afe0d9fa1b` |
| test-clean | ls-test-clean-4507-16021-0058 | 8 | c236cd7f13c7f2639ac253c309b6c21d546aac29f50593b3ba1e7f84fe616c8c | `ee4f92816e10249be92d08b63a1aac451d95f7c02179b80d88e915a92ddd1767` |
| test-clean | ls-test-clean-4970-29095-0002 | 13 | 65fe9e8d47aff0d42b5918fa9aafe611fdddc93b8858e466b9577efe91a7ad12 | `38f093ecf385c3412350bac380a6d1b8bb8889ac8baad40fd270e482244700d8` |
| test-clean | ls-test-clean-4992-41797-0015 | 30 | 1fc5773314919c8012f97d56723388a6befb7c5cc17f463fa830398330a0a4fe | `99046e71acf029ea71b019e59ee9ac2ff1e1a2bc6b27506a726a9db163bc4bee` |
| test-clean | ls-test-clean-61-70970-0011 | 16 | 75e669b68ccb7686f78d6227dbbfc25e9f66e3dc6b817b02a2fab5c1196d94b7 | `5d8b80ff6b40498b7d392648df0975cdbdb6c270503ece29faf932dc2c7d3d60` |
| test-clean | ls-test-clean-6829-68771-0030 | 17 | fbb99918869de67cd11ecd35fccf05d3b9ba7ba0de5d1183db2ceaa10a3ef5f0 | `78fcd2c61947efb7036949dae2ece994cc10fdfe628c71be95c889ec2f09e4ac` |
| test-clean | ls-test-clean-7127-75946-0009 | 12 | b65a6039e3d0f4bdde3eb8f7c193af2bf48ff82369965e3310e3ccab78bc0d08 | `c01e673e9d9259f6ca17fbde23da195c32877ed1409b039378f389aa60cc24e9` |
| test-clean | ls-test-clean-7176-92135-0018 | 27 | f49073c8aa17da02b2b0639369978d3a4c4af8dd74a1cff0f4614953a2ac666e | `54ab36bd0c68f555d8b872ab50ba427af7e15430a969bf464a773d744aaec5dc` |
| test-clean | ls-test-clean-7729-102255-0023 | 10 | 996a32b70e1851af5372a32bbc2b2899bf06bbbd161a9414a1f99118f26a8a24 | `fbb3611ba55f999e4782af90d31e4d731f1d4b869c5f29d929351b3c34cf8224` |
| test-clean | ls-test-clean-8230-279154-0011 | 12 | dc8cb596dd4211fd11b0e55f11f8192c425d43957fbc795f33d5f8be372b78ff | `d88156471cdaadeb19e2b9411b7e7cef1793cc5fbd22907175f817dc639136b5` |
| test-clean | ls-test-clean-8455-210777-0037 | 10 | 4af3329969e0f398ea43d2be7b278776baa1bed28e313c0e2f091da363256aa1 | `f9ebc1b766a6132b170721d4defca89fa8694ae58cc7de5116016bd68ac82cca` |
| test-clean | ls-test-clean-908-157963-0014 | 11 | 35bb92d7da9f5472ab74a0fd16688e9739d86999017882ca2c8358a3a5dfb405 | `85a3169d5e7499d62fff638cc86e282b2de56c4ecbbb3a9aa7ca4cd1e91ad058` |
| test-other | ls-test-other-2609-156975-0000 | 12 | da4a25a42447ac2efb2c4bf427ee83cabbf789e51a20cfbe95fda8461c26d76b | `37b36b31f0653ff05050cd39d9453638e1c8051e4331b6959cc7f2d4db7fe2ef` |
| test-other | ls-test-other-3080-5040-0016 | 18 | d95e960697381f2d028985cd69b7569eb5cfeaaf3adb33e47449f3f0dfe694ad | `4705b0fc85db3df89eb06b542a8c48600252fb79eff755515a19d082d5eb2bb9` |
| test-other | ls-test-other-3528-168669-0043 | 10 | d071a0bdb47a8d924c03c62240613d04335ed61caec31ccde0facef042f92f84 | `e4ef5fb2bdbd216edcee4c34e5a99565543132bb91d2e3f7cfdf1fa9eff42a55` |
| test-other | ls-test-other-3538-142836-0006 | 18 | a3e636a5813ed01e48756a32859c4a32cc5edb17c700a1410d0eaecdd65a4284 | `224c7d9e0a8e982d1341d4eef44bb5be1aced28d7ba44fc32b379894ca370205` |
| test-other | ls-test-other-4198-12259-0026 | 15 | 776f18edf77e50dd07f3de821c05c8bd71a0696fa27e36433e3c0ac5b227dc50 | `9b53e9842e2d764bbe4f708c3854559a6a2bb8fbb115989dd490c1fa1df524ad` |
| test-other | ls-test-other-6128-63244-0013 | 10 | cdc1c8aa9174b98c2eaf0cfe2ddb73d6b2361c347227b38a2ffc0d5ead5c4383 | `f80a3d98741f3c43d5606be0e67e7b60201a6874105460ccc492d4a04dbcca27` |
| test-other | ls-test-other-6432-63723-0046 | 19 | 956415288c8bf740b9b8db8f37e1ce15ab817f88578afe8fb2e744bc0c1cea82 | `f4a62d7c0340003e34e99578982e139a1268f9a38d33eab6392ea0b7b586bac9` |
| test-other | ls-test-other-7105-2340-0033 | 27 | 92114c1d59b5d0e04984e651dd151729faf41453db2b7dd9bad84ddf04b6ddc6 | `457490b453babdd2f620dc31f8fc8ce18df6d1155b05fe95991ce3bc9fbb6294` |
| test-other | ls-test-other-8188-269288-0027 | 12 | 042a2cba559599707040b61d71bb8df67fbad439ae2ef02ca43ae18b2cb575c8 | `076a1649142834d817239700d2698ba87422d6f7f4548627939972337c24c757` |
| test-other | ls-test-other-8280-266249-0004 | 17 | 35ada150736b31211d48d52d8f5d96f4aafde1413bb34eec1e865cf4e0551e58 | `1d06ffa6feae0d561f191e5c03e548f2959b0abee7cf97bbbe2b4fdf5c6ffa96` |
| noisy | smoke-mix-01 | 12 | 87910b29bb221a77c7c49aae0d15a1f4c1a9473281f693bf5024d4b56e62e2ab | `cc576a2380e65016c831dae924e4de5441da4481e0e7e05a113df7a0f934cff2` |
| noisy | smoke-mix-02 | 25 | b888aff1a8cf3bd2a35cc8cedcf51e7015fff0800587946491ae250e2dfb0590 | `cfd0c2ebfb026b5237f0599ae8bfb8c02684c354360433e21c1da0d6e7ebeba8` |
| noisy | smoke-mix-03 | 19 | bcf0d81630c3e6bc5224d712424e3cea1d7b711ed7f35bfc7a7ae97b34b50b37 | `74596054e6f7c7afdf0e15716d65ecc474e4a1fd42c13ec3b4df1791a7171e4f` |
| noisy | smoke-mix-04 | 14 | e758403d33ad61c1caa27def162b7e7c6303b3756016c7a6013ce7a9bc3332e1 | `5192a2595b7b6adef3f7cec08b05b0c953b0112fd8542165e1ff06cc96d5da2f` |
| noisy | smoke-mix-05 | 16 | 070d138be7141aeb954c90b79b133fd709a9471b5d07f0371116e2c7c44f476f | `7107ce9e162873de0e98346157a76dbd04daa4bc5dbc81989e98c036799d5302` |
| noisy | smoke-mix-06 | 10 | c504300185d5fe7dd696fc1fde33810a22f1973177c97c9f4ff00c80099977ff | `2fcf0e6fe787b705ad73d03993f4879f7fbc520afeb8106a60afc50d7f3f6187` |
| noisy | smoke-mix-07 | 26 | 40a2aaa60d1da5489c171a1642ddd15cdc11e92ef3dee6d7c0cff31970c7f034 | `0805f5acaf4ff4c107862cdf935f10b45062ed0157d4f50b5efc33e1822066eb` |
| noisy | smoke-mix-08 | 23 | 150510b8461a309c5c4c998501060512397fd365cc24b69db00c4ac29c957563 | `f6d4f5c192f6ab0bde104c4a8758a3b64755017ceabf1e29eeaceec9fef86ad9` |
| noisy | smoke-mix-09 | 25 | 6a6abb83e505d3353861d315868bc023638ba33dc88d11b2399f732ad49c0c88 | `a6b7c741757faba974b7695ab8d0340b5de448f27168be03d41cb391b2187274` |
| noisy | smoke-mix-10 | 19 | b37dd1a23cdf37e3bbcadc14374e046e3772400577924656ea82b6c28873391c | `7aafc1db19b09317e073cd3d6095b07291e36c7a6359650c3bfd25778efa6a1d` |
| non-speech | smoke-music-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `4e5a1c130dbdf7b7dab972a6775fc233f7e6ff50b7a19aca26391582552778cb` |
| non-speech | smoke-music-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `2c395fa3665a44d995188edbc2c91d8dfe1c2720fc8d4a29b2e3fb5f27232998` |
| non-speech | smoke-music-03 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `ba6ffd892371aa2f1185120c28a0508207373eda80edd7fe0209eb79871b3a9a` |
| non-speech | smoke-music-04 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `4adbf9951cdbd8ae8978e6fb49f1a2366c6616b6f3aa788e87fd0878aea4a3e4` |
| non-speech | smoke-noise-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `af33728eb3cde7ea7038a2854dfd8a757d0b702a5f907219885e1ca9c47db613` |
| non-speech | smoke-noise-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `45ff2951954e38c36a5086cff0f78081f17ae3b783ab7fac7e32e44af29d89e5` |
| non-speech | smoke-noise-03 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `6245c968634b6d5bdaa8740130f0513827d535e56711c06c94781497b41a8eca` |
| non-speech | smoke-noise-04 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `4a7fcdaa7d9c74c27945b8a1acde2630a2b3d99af47002fd04706dbea6dfc5c3` |
| non-speech | smoke-silence-01 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `2cc1cc06ceaa928396e1a362b54b79e3d60aecb778f8c738349c8e7fceaddf44` |
| non-speech | smoke-silence-02 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | `e04968d07f8bf8e43d5126a07a0852a19835fce9d012ef03fb14a5afa17e50b9` |
| tts | tts-smoke-01 | 10 | 30640fce942d691c56bee86a2c000dfa620f2087b3ae22ec8abfd29c65b1eae1 | `aea8e803f1312e324eac1a5dd5bd3558cfc8a924854a1660f49337234ecd8ef5` |
| tts | tts-smoke-02 | 10 | abfd320d882a8ec2ab888bf778f93eb52b29468e59b83822a313cc0e2881b132 | `ab280836d2fbd89e25603cbb1b3aafdc48c71a50453d4b0c5d8b08d68f07f577` |
| tts | tts-smoke-03 | 10 | 25174bb2bfba68f128584857466e3aedcfbff528c3f8db91ffb1e738affc996e | `d892bb8d8130dcf67cc4047b9837260335432dbec1e79bf39692c8e8f6a78639` |
| tts | tts-smoke-04 | 9 | cb28d461f9814fb2319952d57cc1019fe6ad9a1b65321c667691c39387880a4e | `f20a03336177e4a35e14f12c0eeba3c45455520b5e4a46c241433d30f91ae044` |
| tts | tts-smoke-05 | 10 | de58dde5982f4880069fe246f111f88c13439cd7820235377345fcfcd7eac6d0 | `0c25f69a058d480e52c69da0a4b58d293d2c96efc45d937c792ea377055e1079` |
| tts | tts-smoke-06 | 14 | 970e3092763b6055b4e31fd58c3dc4880f6053da1d3fb5eca16374419517a723 | `27de39e730badd9b6e67ac9060a02c843d9e3f58ecf70b0cda465c266e274324` |
| tts | tts-smoke-07 | 10 | 36ecaa833075d36b7382d79b1e10b2e2e3e92f761b443f9fb79c51bc7ded9b39 | `2eef34e87ec83f7bc939efb3f630f8bc7d38d94400e5b7e844d22acc8522b245` |
| tts | tts-smoke-08 | 12 | 86ef79838b484c35c0ae08df921acae131a03cb554d88ec1e524f86838d2170d | `c43790b9adb91fb018386a632d0888a6895a2a3f5ecf2c76c3add168d6b10073` |
| tts | tts-smoke-09 | 10 | a00dec41576b4f0fd1291d42ebbcd1c65945a112a2e6fb04df34e92a4d3978d4 | `6df5d09d8e7471c89b74c966ce28cc6fd4b0fa2a145e9281617b7db5d1b58e73` |
| tts | tts-smoke-10 | 14 | a91a12354baa65c26dadf08f967e597bdd324308938da754e82bffc5545968bb | `37a1d025df869a2e08f7a32bf9e8e40ddf16e6cf40c333829a057ed7e2035421` |

## Real-speed Vosk (20 ms frames, never faster than real time)

First-partial latency: first partial event minus the delivery of the frame holding the first recognised word's start. Finalisation latency: last final event minus the audio-end mark. Both in milliseconds (owner decision, question 7).

| clip_id | audio_s | first_partial_latency_ms | finalisation_latency_ms | max_frame_lag_ms | row |
| --- | --- | --- | --- | --- | --- |
| ls-test-clean-3570-5695-0009 | 5.0250 | 225.0800 | 32.2831 | 288.3487 | `63e3a71797502c1cd385f5604bb29efbcec8744c8a975fff13f966c3a1a50a76` |
| ls-test-clean-6829-68771-0030 | 6.2250 | 593.5512 | 23.2753 | 134.0884 | `c1b45bd2486fbad944f35ee48f5fa43f9e58a8ad945c66cbd6353a9902a32a64` |
| ls-test-other-6128-63244-0013 | 4.1450 | 740.4824 | 31.3153 | 271.3636 | `714fadc0c11061668ca5a68afddca14c1001b9e41cf84b919842a4ecf9a0bfaf` |
| smoke-mix-01 | 5.2250 | 435.7056 | 11.3555 | 189.6243 | `8c05ad82f3a6d67eaf94b134591b82c8fd3cfa103f1f993f6ef227b557ca9c29` |
| tts-smoke-04 | 4.9750 | 726.8046 | 12.9493 | 180.5859 | `b53c9f2226f47017ad80027120d93d47a5f34c8350dbf7f34d3769cc093384a6` |

- First-partial latency: median 593.5512, maximum 740.4824 ms.
- Finalisation latency: median 23.2753, maximum 32.2831 ms.
- Real-speed transcript equal to the batch transcript: 5 of 5 clips.

## Harness VAD (webrtc_vad_mode2, 20 ms frames)

| category | clip_id | speech_frames | speech_s | row |
| --- | --- | --- | --- | --- |
| test-clean | ls-test-clean-1188-133604-0029 | 115 | 2.3000 | `33d10ca6f72a0f1e0b31c2d9f5dc2f9b90efe2c090e456c7f06cd86e37fc2b96` |
| test-clean | ls-test-clean-121-127105-0012 | 227 | 4.5400 | `59e77dc3756162cafa50cc7a7d747fbfb721c1da7bcade58ede77fef589db41d` |
| test-clean | ls-test-clean-1221-135767-0014 | 315 | 6.3000 | `a66514cff008c1a6f0e5b7efb58fbebe28bc4817c9065c91af8213e9e7afacf0` |
| test-clean | ls-test-clean-1580-141083-0035 | 212 | 4.2400 | `549f2058d21e1602c39c13da1bb5395138f02e9ffe57b269885f46c4c0397496` |
| test-clean | ls-test-clean-237-134493-0011 | 238 | 4.7600 | `22f77e1680095ad3ecec444bb34cc0327d103f832f9c3304d10d366b2c784963` |
| test-clean | ls-test-clean-2830-3980-0007 | 430 | 8.6000 | `2b9e422e28d428d0a984cc1228c7676f8d26505f16225a119138965254c01867` |
| test-clean | ls-test-clean-3570-5695-0009 | 221 | 4.4200 | `38d8f26eba8900bc29cf2b90f906b75fc271cf927674bc3269bac34220bc8130` |
| test-clean | ls-test-clean-4077-13751-0014 | 595 | 11.9000 | `dc6959f32a633829da450ada0061d8d92679ec616f51bc4c3f3519af359393c1` |
| test-clean | ls-test-clean-4446-2271-0024 | 133 | 2.6600 | `2e69398c3addd06424ac3249865e691bbbfba0fef4228764042fa5061e7dd8b0` |
| test-clean | ls-test-clean-4507-16021-0058 | 122 | 2.4400 | `df964ccb79947d09cb12f138ded9be4f0cb85a495d4490183cbba173a2602194` |
| test-clean | ls-test-clean-4970-29095-0002 | 217 | 4.3400 | `47c27696cebd13dbff937b4944a51ff7f0085e5dd1127acf4893aab53639bfcb` |
| test-clean | ls-test-clean-4992-41797-0015 | 380 | 7.6000 | `26104b31944a8236a741676cdc78e1fad1c6ee98dacfcbf8d92e8f4bfbd08a84` |
| test-clean | ls-test-clean-61-70970-0011 | 273 | 5.4600 | `7a3027416096bbe3f56f4cb87f2f7a137f6011963a2a8e919ffc4e6a19fe1562` |
| test-clean | ls-test-clean-6829-68771-0030 | 295 | 5.9000 | `c7e7ee9aed1ab1355f8d2c4c5c78ae508fc400faab5c0fef65e5cd5022b862da` |
| test-clean | ls-test-clean-7127-75946-0009 | 198 | 3.9600 | `da2f3b9930c05699a809b9dfbcaae988b17679e953729841128445d25b558cc8` |
| test-clean | ls-test-clean-7176-92135-0018 | 419 | 8.3800 | `8f55898d0af63df65dc5db7ed3b6dc9dd498135f4a4625b450e37e078b79ff4d` |
| test-clean | ls-test-clean-7729-102255-0023 | 260 | 5.2000 | `011dd9b743d54855d953827a4ff5c206c42edb71561eef5fe9a3738aa6c5072d` |
| test-clean | ls-test-clean-8230-279154-0011 | 282 | 5.6400 | `1f4d0c4cf2b577c6212c25ee5b72c4ef08cc476507c76b966317a9df4611a22b` |
| test-clean | ls-test-clean-8455-210777-0037 | 170 | 3.4000 | `31674055fc7765619fb32900866d243855b13d5d50971aea11e4e4d08a689b43` |
| test-clean | ls-test-clean-908-157963-0014 | 199 | 3.9800 | `c2f166d3e89690c3551132f3ecc331b439b349fbdc4cd6f89665a8c455a83848` |
| test-other | ls-test-other-2609-156975-0000 | 176 | 3.5200 | `88ab4826b500ea0ccf9353c386907aebfdeccacaf5f8877d8f6055ba1c3fdae5` |
| test-other | ls-test-other-3080-5040-0016 | 218 | 4.3600 | `f96322dbde55ce7b382abadf2f9ba4183c8047aa1f183203eede50a23b806061` |
| test-other | ls-test-other-3528-168669-0043 | 166 | 3.3200 | `6936e1acca1ceba14fdc31fbe58eee7c954f147da682d563a4df8108136a9d60` |
| test-other | ls-test-other-3538-142836-0006 | 235 | 4.7000 | `cae52be5ad5d301dbec50a465eb8e3914b4dc613eccad0e50eff5688315003c9` |
| test-other | ls-test-other-4198-12259-0026 | 214 | 4.2800 | `f0617683aa83edc351b97f7f521789ca9818e2c5d553e39bae442fc8a0575d8d` |
| test-other | ls-test-other-6128-63244-0013 | 180 | 3.6000 | `d906fd544f80846e08b5510467676e9949b178c74c9ee3ac76720bdb2c77ea8d` |
| test-other | ls-test-other-6432-63723-0046 | 272 | 5.4400 | `1d0aac8eed53dee79439af3af516171624be8ed3f30b4169feeca0dc3e8b3f5b` |
| test-other | ls-test-other-7105-2340-0033 | 471 | 9.4200 | `693291d8215dfc71cdb6be883ca7f51a5dc53d0f1f175d95c89c447671810fb3` |
| test-other | ls-test-other-8188-269288-0027 | 160 | 3.2000 | `72968f2f948836f1b8dce5089ad79fb370ec38724480617a2e6886b2d96c511e` |
| test-other | ls-test-other-8280-266249-0004 | 240 | 4.8000 | `779bf85b654b3c9f4fa7d0ee7243cd3b5ecee15e8b7544efe42da3c20792cbb8` |
| noisy | smoke-mix-01 | 260 | 5.2000 | `b94354d71607526f93a77adfc720accf9e5aea8f90ffbc992b63c6a5887ad16e` |
| noisy | smoke-mix-02 | 463 | 9.2600 | `8198681fe50a3dad32892ab989b95f64abb5fb67629b73045696ddfc2009b36b` |
| noisy | smoke-mix-03 | 370 | 7.4000 | `b8c38855ff611bc814acc98d7dc751ed997262ff930888d6ed18c01b452b331c` |
| noisy | smoke-mix-04 | 253 | 5.0600 | `3de2556eddf48699fdc0dc3b8d0a34c26192c8e5798698bf8cdf28947f61a512` |
| noisy | smoke-mix-05 | 302 | 6.0400 | `4a4f0d3080074482d6ca9591770b0b483e6d6536d95b19b0a528541b9a70f8e5` |
| noisy | smoke-mix-06 | 156 | 3.1200 | `fca8c5970b568bf47c3cfc2760eec4c42ad02757def7aa3b5adf5b4b55800489` |
| noisy | smoke-mix-07 | 446 | 8.9200 | `f6a32c63e5a6b6c47781b8ac67469292da1e49e1f53b568c4bb9b699145ff8ee` |
| noisy | smoke-mix-08 | 341 | 6.8200 | `8793eb5d4d25237f664e4f8c6d6b1966e5689e43bec32953fe1407a5e4605045` |
| noisy | smoke-mix-09 | 379 | 7.5800 | `3f8034f8b1f5175db61d1954cc1836de2fa93ed7c921f3073fc9bb3d392c8f10` |
| noisy | smoke-mix-10 | 330 | 6.6000 | `e8b9bbadc607c8a70ef170d24b5b37b37d41fc826dfc26d4a0d0a288d1d9caa5` |
| non-speech | smoke-music-01 | 490 | 9.8000 | `585c3bc2460831f89692cfc030fb383f7f2d386347b8e9c2b3826d9c3bf1219e` |
| non-speech | smoke-music-02 | 500 | 10.0000 | `ad08306bdc1eac034be2c4d415965d5cf2e1061f1b9b21afb3840ba64b904bac` |
| non-speech | smoke-music-03 | 4 | 0.0800 | `a8847c23f16325afff5ebfb63eb7b0a29e54d1700f727a72a5008a7626275b25` |
| non-speech | smoke-music-04 | 500 | 10.0000 | `62b10fe5bae5300a15861d1f348e82341c169f0b790192323c6b675f9e1d93da` |
| non-speech | smoke-noise-01 | 117 | 2.3400 | `ab0255ae78b28253c94d8e2fa6d187aa9f92d73523da172c910c738df7bd729e` |
| non-speech | smoke-noise-02 | 500 | 10.0000 | `8dae8679947ac245cb369205a93983c95ec258743193ad13fc97b678d532f005` |
| non-speech | smoke-noise-03 | 260 | 5.2000 | `b8e11023982e0289ef5ff96151d15c4e43c4446304f9176e2949f9065b310fb5` |
| non-speech | smoke-noise-04 | 8 | 0.1600 | `f6d7bf7237a7c154e87c80b7feca49342e68fa28e2c9d03dead82dcfe12684a6` |
| non-speech | smoke-silence-01 | 0 | 0 | `751b0680aad8551e1054ebc5b5a3cd84925294baeaa71c601c3a919850823249` |
| non-speech | smoke-silence-02 | 0 | 0 | `ef00713033baff8430ed96531c1fd937b8ab75ed9b09ebc16842cb16e07bed39` |
| tts | tts-smoke-01 | 134 | 2.6800 | `6672dcd791f72ccdee6d3370606bf70164ae1990383d80ed80fd3c428a79341b` |
| tts | tts-smoke-02 | 167 | 3.3400 | `f0bfee53733c8f97f0796282d3a7462243e03771e803ca7444f120ff54cf6b9c` |
| tts | tts-smoke-03 | 141 | 2.8200 | `e501135bb3a9986452c8006e49cd19d56689d58a8bcc36c2bdb06d66c9934961` |
| tts | tts-smoke-04 | 168 | 3.3600 | `876421b5365fa56c1cdec736704e7b6ebf9825af475ccbfc98cd196a68e5cc17` |
| tts | tts-smoke-05 | 143 | 2.8600 | `45bbe3025945f3bcfb02a569bccc9e6c121d9fa7efad068584e3d02060cc31bc` |
| tts | tts-smoke-06 | 156 | 3.1200 | `1e23aef251a4cc11c4d0ccc59e9149a6df1a855a876122335dba71e67a0fdeb3` |
| tts | tts-smoke-07 | 145 | 2.9000 | `c343a2d38a27b42913f78448154712fffc00870ee8103327e9a5f73a3d9cd15f` |
| tts | tts-smoke-08 | 185 | 3.7000 | `7a69b3039a9a43a29c63108bc1774992c42a2f3cdb7046c935d9d0ad75c36841` |
| tts | tts-smoke-09 | 136 | 2.7200 | `d8fa54a9eb0363a597089251cae13962f62cdbf31ad2b55e553b33ab1da94706` |
| tts | tts-smoke-10 | 145 | 2.9000 | `24b114bd77d1f905259839dab3b6ef4bb9cc4403a5e4a8ece72e411aa11493c6` |

Parakeet: not run on target oracle (a CPU target; FR-0.7-07 runs Parakeet on the GPU target only).
